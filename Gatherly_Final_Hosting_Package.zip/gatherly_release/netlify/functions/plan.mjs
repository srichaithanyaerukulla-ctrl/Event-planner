import { MEASURES } from './_lib/measures.mjs';
const allowedTypes = new Set(['wedding', 'birthday', 'community']);
function fallbackPlan(d) {
  const wedding=d.event_type==='wedding', birthday=d.event_type==='birthday';
  const categories=wedding?['Venue','Catering','Decor and florals','Photo / video','Sound / lighting','Transport']:birthday?['Venue or home setup','Food and cake','Decoration','Photography','Music or activities']:['Venue','Food / refreshments','AV and internet','Signage','Activities / speakers','Volunteer support'];
  const rows=[[60,'Shortlist and inspect venues','Confirm capacity, accessibility, setup window and cancellation terms.','Venue','high'],[45,'Request comparable vendor quotes','Compare inclusions, taxes, deposits, exclusions and validity.','Vendors','high'],[30,'Confirm event format','Agree on the running order, key moments and decision owners.','Planning','medium'],[21,'Send invitations','Include RSVP deadline and arrival information.','Guests','high'],[14,'Review RSVPs and quantities','Reconfirm vendor change terms.','Guests','high'],[10,'Approve vendor scope','Confirm deliverables, timings and payment milestones.','Vendors','high'],[7,'Walk through event-day plan','Assign owners, arrival times and contingency actions.','Operations','high'],[3,'Reconfirm critical details','Check venue access, vendor arrival and headcount.','Operations','high'],[1,'Prepare event-day run sheet','Keep the latest schedule and contact list accessible.','Operations','high'],[0,'Run event and capture actuals','Track changes and record lessons.','Event day','medium']];
  return {theme:wedding?'A guest-first wedding celebration':birthday?'A personal, joyful celebration':'An inclusive community gathering',summary:`A practical first draft for ${d.title}. All costs and vendor details are assumptions until confirmed directly.`,ideas:wedding?['Plan guest-friendly transitions between ceremony, photos and reception.','Assign one decision owner for each major function.','Keep a contingency reserve.','Share arrival and accessibility information in advance.']:birthday?['Choose one signature memory-making activity.','Offer optional activities for different ages.','Use reusable or borrowed decorations.','Provide comfortable seating and clear arrival instructions.']:['Create a simple check-in and signage flow.','Assign an owner to each activity.','Offer activities for different mobility needs.','Publish the schedule and access details.'],tasks:rows.map(([days_before,title,detail,category,priority])=>({days_before,title,detail,category,priority})),vendor_categories:categories,risks:['Treat estimates as assumptions, not verified market quotes.','Confirm capacity, availability, taxes and cancellation terms directly.','Review task dates and quantities after event changes.'],generation_mode:'rules-based-fallback'};
}
const DOMAIN_TERMS = {
  budget:['budget','cost','expense','saving','afford','cheap','value','cap','overspend'],
  venue:['venue','hall','location','outdoor','indoor','capacity','site'],
  catering:['food','catering','meal','menu','vegetarian','vegan','refreshment','water'],
  accessibility:['accessible','accessibility','wheelchair','mobility','hearing','visual','inclusive'],
  safety:['safety','emergency','medical','first aid','fire','crowd','security'],
  schedule:['schedule','timeline','timing','run sheet','agenda','late','setup window'],
  vendor:['vendor','supplier','quote','contract','booking','deposit'],
  guest:['guest','attendee','invite','rsvp','family','children','elderly'],
  weather:['weather','rain','heat','cold','wind','storm','monsoon'],
  transport:['transport','parking','bus','train','traffic','pickup','drop'],
  decor:['decor','decoration','floral','stage','signage','theme'],
  av:['audio','visual','av','microphone','speaker','projector','internet','wifi'],
  privacy:['privacy','data','consent','photo','photography','recording'],
  sustainability:['sustainability','sustainable','waste','reusable','recycle','plastic','low-waste'],
  staff:['staff','volunteer','team','crew','roster','owner'],
  wedding:['wedding','ceremony','reception','bride','groom'],
  birthday:['birthday','cake','party','milestone'],
  community:['community','public','neighbourhood','neighborhood','local group'],
  children:['child','children','kids','family-friendly'],
  food_allergy:['allergy','allergen','intolerance','gluten','nut-free','dietary restriction'],
  registration:['registration','check-in','check in','ticket','entry'],
  communications:['communication','message','announcement','email','whatsapp','reminder'],
  finance:['payment','invoice','cash flow','refund','tax','gst'],
  contingency:['contingency','backup','risk','fallback','plan b'],
  permissions:['permission','permit','license','licence','approval','noise limit']
};
function selectMeasures(d, limit=12) {
  const text = `${d.preferences||''} ${(d.priorities||[]).join(' ')}`.toLowerCase();
  const eventType=d.event_type;
  const guestCount=Number(d.guests)||0;
  const scoreRows=MEASURES.filter(m => m.event_types.includes('all') || m.event_types.includes(eventType)).map(m => {
    let score = m.priority === 'high' ? 1.5 : m.priority === 'medium' ? 0.75 : 0;
    const terms=DOMAIN_TERMS[m.domain]||[];
    if(terms.some(term=>text.includes(term))) score+=5;
    if(m.domain===eventType) score+=5;
    if(text.includes(String(m.scenario||'').toLowerCase())) score+=2;
    if(guestCount>=200 && ['safety','registration','transport','catering','staff','crowd'].includes(m.domain)) score+=2.5;
    if(guestCount>=500 && ['safety','registration','transport','staff'].includes(m.domain)) score+=2;
    if(guestCount<=30 && ['guest','catering','budget','venue'].includes(m.domain)) score+=1;
    if(eventType==='wedding' && ['wedding','venue','catering','schedule','privacy'].includes(m.domain)) score+=2;
    if(eventType==='birthday' && ['birthday','children','catering','guest','decor'].includes(m.domain)) score+=2;
    if(eventType==='community' && ['community','accessibility','registration','communications','sustainability'].includes(m.domain)) score+=2;
    return {m,score};
  }).sort((a,b)=>b.score-a.score || a.m.id.localeCompare(b.m.id));
  const chosen=[]; const domains=new Set();
  for (const row of scoreRows) {
    if(chosen.length>=limit) break;
    if(domains.has(row.m.domain)) continue;
    chosen.push(row.m); domains.add(row.m.domain);
  }
  return chosen;
}
function validPlan(p){return p&&typeof p==='object'&&Array.isArray(p.tasks)&&Array.isArray(p.ideas)&&Array.isArray(p.vendor_categories)&&Array.isArray(p.risks);}
export default async (request) => {
  if(request.method!=='POST') return new Response('Method not allowed',{status:405});
  let d; try{d=await request.json();}catch{return Response.json({error:'Invalid JSON body'},{status:400});}
  if(!allowedTypes.has(d.event_type)||typeof d.title!=='string'||d.title.length<2||d.title.length>120||!/^\d{4}-\d{2}-\d{2}$/.test(d.event_date||'')||!Number.isFinite(Date.parse(String(d.event_date)+'T00:00:00Z'))||new Date(String(d.event_date)+'T00:00:00Z').toISOString().slice(0,10)!==d.event_date||!Number.isInteger(Number(d.guests))||Number(d.guests)<1||Number(d.guests)>20000||!Number.isFinite(Number(d.budget))||Number(d.budget)<0)return Response.json({error:'Please provide a valid event type, title, date, guest count and budget.'},{status:400});
  const clean={event_type:d.event_type,title:d.title.slice(0,120),event_date:d.event_date,city:String(d.city||'').slice(0,100),guests:Number(d.guests),budget:Number(d.budget),currency:String(d.currency||'INR').slice(0,3),preferences:String(d.preferences||'').slice(0,1200),priorities:Array.isArray(d.priorities)?d.priorities.slice(0,8):[]};
  const recommended_measures=selectMeasures(clean,12);
  const p=fallbackPlan(clean);
  p.recommended_measures=recommended_measures;
  p.measure_catalogue={total:MEASURES.length,version:'1.0.0'};
  p.generation_mode='deterministic-rules';
  return Response.json(p);
};
