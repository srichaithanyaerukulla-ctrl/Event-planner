import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import planHandler from '../netlify/functions/plan.mjs';
import healthHandler from '../netlify/functions/health.mjs';

const catalogue = JSON.parse(fs.readFileSync('public/data/gatherly_measures_1000.json', 'utf8'));
const measures = catalogue.measures;
assert.equal(measures.length, 1000, 'catalogue must contain exactly 1,000 measures');
assert.equal(new Set(measures.map(m => m.id)).size, 1000, 'measure IDs must be unique');
const required = ['id','domain','domain_label','event_types','scenario','title','action','why','priority','stage','trigger','verification'];
for (const m of measures) {
  for (const key of required) assert.ok(m[key] !== undefined && m[key] !== null && m[key] !== '', `${m.id} missing ${key}`);
  assert.ok(['low','medium','high'].includes(m.priority), `${m.id} invalid priority`);
  assert.ok(['all','wedding','birthday','community'].some(t => m.event_types.includes(t)), `${m.id} invalid event type`);
}
assert.equal(new Set(measures.map(m => m.domain)).size, 25, 'expected 25 domains');
assert.ok(measures.every(m => m.why.length > 40 && m.verification.length > 40), 'rationale and verification must be actionable');

const base = { title:'Test event', event_date:'2027-01-16', city:'Hyderabad', guests:250, budget:180000, currency:'INR', preferences:'accessible, vegetarian, low waste, rain backup', priorities:['budget clarity','guest experience'] };
for (const event_type of ['community','wedding','birthday']) {
  const response = await planHandler(new Request('http://local/.netlify/functions/plan', {method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...base,event_type})}));
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.tasks.length, 10);
  assert.equal(body.measure_catalogue.total, 1000);
  assert.equal(body.recommended_measures.length, 12);
  assert.equal(new Set(body.recommended_measures.map(m => m.domain)).size, 12, 'recommendations should cover 12 distinct domains');
  assert.ok(body.recommended_measures.every(m => m.event_types.includes('all') || m.event_types.includes(event_type)));
  assert.ok(body.recommended_measures.some(m => m.domain === event_type), `${event_type} plan should include its event-specific measures`);
}
const invalidDate = await planHandler(new Request('http://local/plan', {method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...base,event_type:'community',event_date:'2027-99-99'})}));
assert.equal(invalidDate.status, 400, 'invalid calendar dates must be rejected');
const invalidType = await planHandler(new Request('http://local/plan', {method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...base,event_type:'concert'})}));
assert.equal(invalidType.status, 400);
const method = await planHandler(new Request('http://local/plan', {method:'GET'}));
assert.equal(method.status, 405);
const health = await healthHandler();
const healthBody = await health.json();
assert.equal(healthBody.model_required, false);
assert.equal(healthBody.measure_count, 1000);

const html = fs.readFileSync('public/index.html','utf8');
for (const asset of ['/styles.css','/app.js','/measures.js','/data/gatherly_measures_1000.json']) assert.ok(fs.existsSync(`public/${asset.replace(/^\//,'')}`), `missing static asset ${asset}`);
assert.ok(html.includes('id="change-form"') === false, 'change form is generated in the app view, not static HTML');
assert.ok(fs.readFileSync('public/app.js','utf8').includes("appView.addEventListener('submit'"), 'change form handler must be delegated');

// Lightweight browser-DOM smoke test for initial app boot without third-party dependencies.
class Element {
  constructor(){this.innerHTML='';this.textContent='';this.hidden=false;this.dataset={};this.value='';this.disabled=false;this.style={};this.classList={add(){},remove(){},toggle(){}};}
  addEventListener(){} querySelector(){return new Element()} querySelectorAll(){return []} closest(){return null} matches(){return false} focus(){} setSelectionRange(){}
}
const elements = new Map();
const get = key => { if (!elements.has(key)) elements.set(key,new Element()); return elements.get(key); };
const document = {querySelector:get,querySelectorAll:()=>[],getElementById:get,body:new Element(),createElement:()=>new Element()};
const context = {document,window:{dispatchEvent(){},addEventListener(){}},localStorage:{getItem(){return null},setItem(){}},console,Date,Intl,Math,Number,String,Array,Object,JSON,Set,Map,Promise,CustomEvent:function(){},URL,Blob,fetch:async()=>{throw new Error('offline test')},setTimeout,clearTimeout,confirm:()=>true,prompt:()=>null};
vm.createContext(context);
vm.runInContext(fs.readFileSync('public/app.js','utf8'),context,{filename:'public/app.js'});
assert.ok(get('#app-view').innerHTML.includes('Community Connect Day'), 'initial overview should render');
console.log('PASS: 1,000 catalogue records; 25 domains; three event-type plan flows; validation; health endpoint; static assets; initial app boot.');
