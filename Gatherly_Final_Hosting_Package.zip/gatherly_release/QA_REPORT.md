# Gatherly QA report

## Automated checks

Executed with Node.js using the included dependency-free test suite.

- 1,000 catalogue records present.
- 1,000 unique stable IDs and 1,000 unique action strings.
- 25 domains, 40 records per domain.
- Required schema fields populated on every record.
- Priority values constrained to low / medium / high.
- Domain-specific rationales and verification instructions populated.
- Community, wedding and birthday planning requests each return a 10-task plan and 12 recommendations from 12 distinct domains.
- Event-specific recommendations are included for the selected event type.
- Invalid event types and invalid calendar dates are rejected with HTTP 400.
- Unsupported request methods are rejected with HTTP 405.
- Health endpoint reports deterministic mode and no model requirement.
- Static assets and initial dashboard rendering pass smoke checks.

Command: `npm test`

## Local HTTP checks

Served the `public/` directory with Python's local HTTP server. These paths returned HTTP 200:

- `/`
- `/app.js`
- `/styles.css`
- `/measures.js`
- `/data/gatherly_measures_1000.json`

## Important test boundary

The Node-based test suite and local HTTP checks do not replace a full interactive browser test, accessibility audit, penetration test, or post-deployment Netlify verification. A headless browser session could not be completed in this execution environment. After publishing, test the full user flows in current desktop and mobile browsers and verify the Netlify Functions in the deployed environment.
