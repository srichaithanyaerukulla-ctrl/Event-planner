(() => {
  const results=document.getElementById('measure-results');
  const search=document.getElementById('measure-search');
  const domain=document.getElementById('measure-domain');
  if(!results||!search||!domain)return;
  let catalogue=[],recommended=[];
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function card(m){return `<article class="measure-card"><div class="measure-card-top"><small>${esc(m.domain_label)} · ${esc(m.stage)}</small><span class="measure-pill ${esc(m.priority)}">${esc(m.priority)}</span></div><strong>${esc(m.title)}</strong><p>${esc(m.action)}</p><p style="margin-top:6px;color:#89968d">Why: ${esc(m.why)}</p></article>`;}
  function populateDomains(){const vals=[...new Map(catalogue.map(m=>[m.domain,m.domain_label])).entries()];domain.innerHTML='<option value="all">All areas</option>'+vals.map(([v,l])=>`<option value="${esc(v)}">${esc(l)}</option>`).join('');}
  function render(){const q=search.value.trim().toLowerCase(),d=domain.value;let rows=recommended.length&& !q && d==='all' ? recommended : catalogue;rows=rows.filter(m=>(d==='all'||m.domain===d)&&(!q||`${m.title} ${m.action} ${m.domain_label} ${m.scenario}`.toLowerCase().includes(q)));results.innerHTML=rows.length?rows.slice(0,40).map(card).join(''):'<p class="measure-empty">No matching measures. Try another search term or area.</p>';}
  fetch('/data/gatherly_measures_1000.json').then(r=>{if(!r.ok)throw Error('catalogue unavailable');return r.json();}).then(data=>{catalogue=data.measures||[];populateDomains();render();}).catch(()=>{results.innerHTML='<p class="measure-empty">The playbook could not be loaded. Refresh the page to retry.</p>';});
  search.addEventListener('input',render);domain.addEventListener('change',render);
  window.addEventListener('gatherly:plan',e=>{recommended=e.detail?.recommended_measures||[];if(recommended.length){results.innerHTML=recommended.map(card).join('');const note=document.querySelector('.measure-head p');if(note)note.textContent=`${recommended.length} measures prioritized for this event from the full 1,000-measure playbook. Search to explore the complete library.`;}render();});
})();
