'use strict';

const STORE_KEY = 'gatherly-event-planner-v1';
const todayISO = () => new Date().toLocaleDateString('en-CA');
const defaultEvent = {
  title: 'Community Connect Day', event_type: 'community', event_date: '2027-01-16', city: 'Hyderabad',
  guests: 120, budget: 180000, currency: 'INR', preferences: 'Warm, welcoming, accessible, low-waste',
  priorities: ['budget clarity', 'guest experience']
};
const budgetBlueprint = [
  {category:'Venue', share:0.22, icon:'⌂'},
  {category:'Food & refreshments', share:0.32, icon:'♨'},
  {category:'Decor & signage', share:0.10, icon:'✳'},
  {category:'Photo / video', share:0.08, icon:'▣'},
  {category:'AV & activities', share:0.07, icon:'♫'},
  {category:'Transport & logistics', share:0.06, icon:'↗'},
  {category:'Supplies & cleanup', share:0.05, icon:'◇'},
  {category:'Contingency reserve', share:0.10, icon:'⌁'}
];
const defaultVendors = [
  {id:'v-venue', name:'Venue to research', category:'Venue', status:'To research', quote:null, contact:'', notes:'Confirm capacity, access window, accessibility, taxes and cancellation terms.', created_at:new Date().toISOString()},
  {id:'v-food', name:'Catering options', category:'Food & refreshments', status:'To research', quote:null, contact:'', notes:'Ask for per-person inclusions, dietary options, taxes and final-headcount deadline.', created_at:new Date().toISOString()},
  {id:'v-av', name:'AV / activity support', category:'AV and activities', status:'Contacted', quote:null, contact:'', notes:'Confirm equipment, setup time, power/network requirements and an on-site contact.', created_at:new Date().toISOString()}
];

function uid(prefix='id') { return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`; }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function amountNumber(value) { if (value === '' || value === null || value === undefined) return null; const n = Number(value); return Number.isFinite(n) && n >= 0 ? n : null; }
function money(value, currency=state.event.currency) {
  const n = Number(value || 0);
  try { return new Intl.NumberFormat('en-IN', {style:'currency', currency, maximumFractionDigits:0}).format(n); }
  catch { return `${currency} ${Math.round(n).toLocaleString('en-IN')}`; }
}
function shortMoney(value) {
  const n = Number(value || 0), symbol = state.event.currency === 'INR' ? '₹' : `${state.event.currency} `;
  if (Math.abs(n) >= 10000000) return `${symbol}${(n/10000000).toFixed(1)}Cr`;
  if (Math.abs(n) >= 100000) return `${symbol}${(n/100000).toFixed(1)}L`;
  if (Math.abs(n) >= 1000) return `${symbol}${(n/1000).toFixed(1)}k`;
  return `${symbol}${Math.round(n).toLocaleString('en-IN')}`;
}
function dateObj(iso) { if (!iso) return new Date(); return new Date(`${iso}T12:00:00`); }
function addDaysISO(iso, days) { const d = dateObj(iso); d.setDate(d.getDate()+Number(days||0)); return d.toLocaleDateString('en-CA'); }
function dateLabel(iso, opts={day:'numeric', month:'short'}) { if (!iso) return 'Not set'; return new Intl.DateTimeFormat('en-IN', opts).format(dateObj(iso)); }
function dayDiff(fromIso, toIso) { return Math.round((dateObj(toIso) - dateObj(fromIso))/86400000); }
function daysToEvent() { return dayDiff(todayISO(), state.event.event_date); }
function initials(name) { return String(name||'G').trim().split(/\s+/).slice(0,2).map(s=>s[0]||'').join('').toUpperCase(); }
function forecastFor(item) {
  if (item.committed !== null && item.committed !== undefined && item.committed !== '') return Number(item.committed)||0;
  if (item.quoted !== null && item.quoted !== undefined && item.quoted !== '') return Number(item.quoted)||0;
  return Number(item.estimate)||0;
}
function budgetTotals() {
  const forecast = state.budgetItems.reduce((a,x)=>a+forecastFor(x),0);
  const estimate = state.budgetItems.reduce((a,x)=>a+(Number(x.estimate)||0),0);
  const quoted = state.budgetItems.reduce((a,x)=>a+(x.quoted!==null && x.quoted!=='' ? Number(x.quoted)||0 : 0),0);
  const committed = state.budgetItems.reduce((a,x)=>a+(x.committed!==null && x.committed!=='' ? Number(x.committed)||0 : 0),0);
  const paid = state.budgetItems.reduce((a,x)=>a+(Number(x.paid)||0),0);
  return {forecast, estimate, quoted, committed, paid, headroom:Number(state.event.budget)-forecast};
}
function budgetItemDefaults(cap) {
  return budgetBlueprint.map((b,i)=>({id:`budget-${i+1}`,category:b.category,share:b.share,estimate:Math.round(Number(cap||0)*b.share),quoted:null,committed:null,paid:0,estimate_mode:'allocation',icon:b.icon}));
}
function localPlan(event) {
  const type = event.event_type;
  let theme, ideas, vendor_categories;
  const base = [
    [60,'Lock the venue shortlist','Confirm capacity, accessibility, included facilities, setup window and cancellation terms.','Venue','high'],
    [45,'Request comparable vendor quotes','Use the same brief for each vendor and compare inclusions, taxes, deposits and exclusions.','Vendors','high'],
    [30,'Confirm the event format','Agree on the running order, theme, key moments and the decision-maker for each area.','Planning','medium'],
    [21,'Send invitations','Share the essentials, an RSVP deadline and a clear contact route for access or dietary requests.','Guests','high'],
    [14,'Review RSVPs and quantities','Compare responses with the guest target and ask vendors how late changes affect pricing.','Guests','high'],
    [10,'Approve final vendor scope','Confirm deliverables, service timings, payment milestones and the responsible contact.','Vendors','high'],
    [7,'Walk through event-day operations','Assign owners, arrival times, setup tasks, emergency contacts and contingency actions.','Operations','high'],
    [3,'Reconfirm critical details','Reconfirm venue access, vendor arrival, final headcount and the backup plan.','Operations','high'],
    [1,'Prepare the event-day run sheet','Keep the latest schedule, contact list and open decisions available offline.','Operations','high'],
    [0,'Run the event and capture actuals','Track important changes, settle approved invoices and record lessons after the event.','Event day','medium']
  ];
  if(type==='birthday') {
    theme='A personal, joyful celebration';
    ideas=['Choose one signature moment: a memory wall, short toast or collaborative wish board.','Offer two or three activity choices rather than overfilling the schedule.','Use reusable signage and decor that can be borrowed or reused afterwards.','Keep a quiet seating area and a simple plan for children or older guests, if relevant.'];
    vendor_categories=['Venue or home setup','Food and cake','Decoration','Photography','Music or activities','Transport / cleanup'];
  } else if(type==='wedding') {
    theme='A guest-first wedding celebration';
    ideas=['Design the day around clear transitions between ceremony, photographs, food and celebration.','Create a single list of key moments and the person responsible for each.','Keep a private reserve for weather, transport, guest and vendor changes.','Share a clear arrival guide and accessibility information with guests in advance.'];
    vendor_categories=['Venue','Catering','Decor and florals','Photo / video','Sound / lighting','Transport','Attire / makeup','Ceremony services'];
    base.unshift([90,'Map functions and decision owners','List each function, location, key traditions and who is authorized to approve changes.','Planning','high']);
  } else {
    theme='An inclusive, easy-to-navigate community gathering';
    ideas=['Provide a simple arrival/check-in flow and clear directional signage.','Set up a host or volunteer roster with one named owner per activity.','Choose activities that work for different energy levels and mobility needs.','Publish the schedule, venue access details and contact point in one shareable place.'];
    vendor_categories=['Venue','Food / refreshments','AV and internet','Signage','Activities / speakers','Volunteer support','Waste / cleanup'];
  }
  const tasks = base.sort((a,b)=>b[0]-a[0]).map(([days_before,title,detail,category,priority])=>({id:uid('task'),days_before,title,detail,category,priority}));
  return {theme,summary:`A practical first draft for ${event.title}. Treat every cost as a planning assumption until a vendor confirms it in writing.`,ideas,tasks,vendor_categories,risks:['Treat budget allocations as editable planning assumptions, not market quotes.','Confirm venue capacity, vendor availability, tax treatment and cancellation terms directly.','Re-check task dates if the event date changes; approve changes before applying them.'],generation_mode:'guided-demo'};
}
function createInitialState() {
  const event = {...defaultEvent};
  const plan = localPlan(event);
  return {event,plan,budgetItems:budgetItemDefaults(event.budget),vendors:defaultVendors.map(v=>({...v,id:uid('vendor')})),guests:[],completedTasks:[],activity:[{id:uid('activity'),title:'Workspace created',detail:'Starter plan loaded in guided demo mode.',at:new Date().toISOString()}],lastSaved:new Date().toISOString(),dismissBanner:false};
}
function normalizeState(raw) {
  const initial=createInitialState();
  if(!raw || typeof raw!=='object') return initial;
  const merged={...initial,...raw};
  merged.event={...defaultEvent,...(raw.event||{})};
  if(!Array.isArray(merged.budgetItems)) merged.budgetItems=budgetItemDefaults(merged.event.budget);
  if(!Array.isArray(merged.vendors)) merged.vendors=[];
  if(!Array.isArray(merged.guests)) merged.guests=[];
  if(!Array.isArray(merged.completedTasks)) merged.completedTasks=[];
  if(!Array.isArray(merged.activity)) merged.activity=[];
  if(!merged.plan || !Array.isArray(merged.plan.tasks)) merged.plan=localPlan(merged.event);
  merged.plan.tasks=merged.plan.tasks.map(t=>({...t,id:t.id||uid('task')}));
  merged.budgetItems=merged.budgetItems.map((item,i)=>({...item,id:item.id||uid('budget'),share:Number(item.share)||0,estimate:Number(item.estimate)||0,quote:null,...item}));
  return merged;
}
let state;
let cachedLocalState=null;
try { cachedLocalState=JSON.parse(localStorage.getItem(STORE_KEY)||'null'); state=normalizeState(cachedLocalState); }
catch { state=createInitialState(); cachedLocalState=null; }
let activeView='overview';
let taskFilter='all';
let guestSearch='';
let toastTimer=null;
let changePreview=null;

const viewTitles={overview:['Make room for the moment.','The moving parts, in one calm place.'],plan:['A plan that keeps its promises.','Small, clear steps from now until event day.'],budget:['Know where every rupee goes.','Planning assumptions, real quotes and commitments—kept separate.'],vendors:['A clearer way to compare vendors.','Track conversations and compare like-for-like, without inventing facts.'],guests:['Every guest detail, thoughtfully organized.','Keep your RSVP picture clear and your guest data private.'],change:['When plans change, see what moves.','Preview downstream effects before you apply an update.']};
const $=sel=>document.querySelector(sel);
const appView=$('#app-view');

function setSaveStatus(label,warning=false) {
  const node=$('#save-status');
  if(!node)return;
  node.innerHTML=`<span class="status-dot"${warning?' style="background:#d9a37d"':''}></span> ${escapeHtml(label)}`;
}
function saveState(message='Saved on this device') {
  try {
    state.lastSaved=new Date().toISOString();
    localStorage.setItem(STORE_KEY,JSON.stringify(state));
    setSaveStatus(message==='Saved to server'?'Saved on this device':message);
  } catch(e) {
    setSaveStatus('Local storage unavailable',true);
    toast('Could not save locally. Export a backup before refreshing.');
  }
}
function csvValue(v) { const s=String(v??''); return `"${s.replace(/"/g,'""')}"`; }
function exportBudget() {
  const rows=[['Category','Estimate','Quote','Committed','Paid','Forecast basis','Forecast amount','Currency'],...state.budgetItems.map(x=>[x.category,x.estimate,x.quoted??'',x.committed??'',x.paid,x.committed!==null&&x.committed!==''?'Committed':x.quoted!==null&&x.quoted!==''?'Quoted':'Estimated',forecastFor(x),state.event.currency])];
  downloadFile('gatherly-budget.csv',rows.map(r=>r.map(csvValue).join(',')).join('\r\n'),'text/csv;charset=utf-8');
}
function exportGuests() {
  const rows=[['Name','Party size','RSVP','Note'],...state.guests.map(g=>[g.name,g.party_size,g.rsvp,g.note||''])];
  downloadFile('gatherly-guests.csv',rows.map(r=>r.map(csvValue).join(',')).join('\r\n'),'text/csv;charset=utf-8');
}
function exportWorkspace() {
  const safeCopy={...state,exported_at:new Date().toISOString(),export_note:'Local demo backup. Contains guest/vendor notes; store and share carefully.'};
  downloadFile('gatherly-workspace-backup.json',JSON.stringify(safeCopy,null,2),'application/json;charset=utf-8');
  toast('Workspace backup exported. Keep it private if it contains guest details.');
}
function reassignTaskIds(plan) { return {...plan,tasks:(plan.tasks||[]).map(t=>({...t,id:uid('task')}))}; }
async function generatePlan() {
  const button=$('#generate-plan-btn'); const oldText=button.innerHTML;
  button.disabled=true;button.innerHTML='<span class="sparkle">✦</span> Building your plan…';
  try {
    const payload={event_type:state.event.event_type,title:state.event.title,event_date:state.event.event_date,city:state.event.city,guests:Number(state.event.guests),budget:Number(state.event.budget),currency:state.event.currency,preferences:state.event.preferences||'',priorities:state.event.priorities||['budget clarity','guest experience']};
    let result;
    try {
      const response=await fetch('/.netlify/functions/plan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      if(!response.ok) throw new Error('Planning endpoint unavailable');
      result=await response.json();
    } catch(_) { result=localPlan(state.event); result.generation_mode='guided-demo'; }
    if(!result||!Array.isArray(result.tasks)||!Array.isArray(result.ideas)) throw new Error('The plan response was not usable.');
    state.plan=reassignTaskIds(result); state.completedTasks=[]; window.dispatchEvent(new CustomEvent('gatherly:plan',{detail:result}));
    logActivity('Planning draft generated','Deterministic planning rules and curated measures used.');
    saveState(); render(); toast('Event plan generated from Gatherly planning rules and measures. Review all suggestions.');
  } catch(e) { toast('Plan generation failed. Your existing plan was kept.'); }
  finally { const b=$('#generate-plan-btn');if(b){b.disabled=false;b.innerHTML=oldText;} }
}
function applyEventUpdate(next) {
  const oldGuests=Math.max(1,Number(state.event.guests)||1), newGuests=Math.max(1,Number(next.guests)||1);
  const ratio=newGuests/oldGuests;
  state.budgetItems.forEach(item=>{
    if(item.estimate_mode==='allocation' && /food|cater|refresh|activity|transport|guest|meal/i.test(item.category)) item.estimate=Math.round(Number(item.estimate||0)*ratio);
  });
  state.event={...state.event,...next};
  logActivity('Event details updated',`${state.event.title}: ${state.event.guests} guests, ${dateLabel(state.event.event_date,{day:'numeric',month:'short',year:'numeric'})}, cap ${money(state.event.budget)}`);
  changePreview=null;saveState();render();toast('Event details saved. Review timeline and budget after the change.');
}

// Core UI layer: dependency-free and deterministic; no model service is used.
function toast(message) {
  const node=$('#toast'); if(!node)return; node.textContent=message; node.classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>node.classList.remove('show'),3200);
}
function logActivity(title,detail) {
  state.activity.unshift({id:uid('activity'),title,detail,at:new Date().toISOString()});
  state.activity=state.activity.slice(0,30);
}
function downloadFile(name,content,type) {
  const blob=new Blob([content],{type}); const url=URL.createObjectURL(blob);
  const a=document.createElement('a');a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);
}
function updateBanner() {
  const banner=$('#ai-status-banner'); if(!banner)return;
  banner.hidden=!!state.dismissBanner;
  const strong=banner.querySelector('strong'),small=banner.querySelector('small');
  if(strong)strong.textContent='Rules-based planning + 1,000-measure playbook';
  if(small)small.textContent='No AI model or third-party AI API is required. Recommendations are selected from a curated, searchable catalogue.';
}
function setView(view) {
  activeView=viewTitles[view]?view:'overview';
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===activeView));
  const title=$('#breadcrumb-title');if(title)title.textContent=activeView.charAt(0).toUpperCase()+activeView.slice(1);
  render();$('#sidebar')?.classList.remove('open');
}
function openEventDialog() {
  const e=state.event;
  $('#event-title').value=e.title;$('#event-type').value=e.event_type;$('#event-date').value=e.event_date;
  $('#event-city').value=e.city;$('#event-guests').value=e.guests;$('#event-budget').value=e.budget;
  $('#event-currency').value=e.currency;$('#event-preferences').value=e.preferences||'';
  $('#event-dialog').showModal();
}
function openVendorDialog(v=null) {
  const f=$('#vendor-form');f.reset();f.dataset.editId=v?.id||'';
  $('#vendor-name').value=v?.name||'';$('#vendor-category').value=v?.category||'';$('#vendor-status').value=v?.status||'To research';
  $('#vendor-quote').value=v?.quote??'';$('#vendor-contact').value=v?.contact||'';$('#vendor-notes').value=v?.notes||'';
  $('#vendor-dialog').showModal();
}
function openGuestDialog() { $('#guest-form').reset();$('#guest-party').value=1;$('#guest-dialog').showModal(); }
function taskToggle(id,checked) {
  if(checked&&!state.completedTasks.includes(id))state.completedTasks.push(id);
  if(!checked)state.completedTasks=state.completedTasks.filter(x=>x!==id);
  logActivity(checked?'Task completed':'Task reopened',state.plan.tasks.find(t=>t.id===id)?.title||'Planning task');saveState();render();
}
function calculateImpact(next) {
  const oldGuests=Math.max(1,Number(state.event.guests)||1),newGuests=Math.max(1,Number(next.guests)||1);
  const variable=state.budgetItems.filter(x=>/food|cater|refresh|activity|transport|guest|meal/i.test(x.category));
  const variableTotal=variable.reduce((a,x)=>a+forecastFor(x),0);
  return {next,guest_delta:newGuests-oldGuests,budget_delta:Number(next.budget)-Number(state.event.budget),estimated_variable_delta:Math.round(variableTotal*(newGuests/oldGuests-1))};
}
function render() {
  if(!appView)return;
  const e=state.event, totals=budgetTotals(), done=state.completedTasks.length, tasks=state.plan.tasks||[];
  const title=$('#page-title'),subtitle=$('#page-subtitle');
  if(title)title.textContent=viewTitles[activeView][0];if(subtitle)subtitle.textContent=viewTitles[activeView][1];
  const count=$('#nav-task-count');if(count)count.textContent=String(Math.max(0,tasks.length-done));
  const pct=tasks.length?Math.round(done/tasks.length*100):0;
  const taskRows=tasks.filter(t=>taskFilter==='all'||(taskFilter==='open'?!state.completedTasks.includes(t.id):state.completedTasks.includes(t.id))).map(t=>`<label class="task-row"><input class="task-toggle" type="checkbox" data-task="${escapeHtml(t.id)}" ${state.completedTasks.includes(t.id)?'checked':''}><span><strong>${escapeHtml(t.title)}</strong><small>${escapeHtml(t.detail||'')} · ${escapeHtml(t.days_before)} days before</small></span><em>${escapeHtml(t.priority||'normal')}</em></label>`).join('');
  const cards=`<div class="stats-grid"><article class="stat-card"><span>Event date</span><strong>${escapeHtml(dateLabel(e.event_date,{day:'numeric',month:'short',year:'numeric'}))}</strong><small>${daysToEvent()} days to go</small></article><article class="stat-card"><span>Expected guests</span><strong>${Number(e.guests).toLocaleString('en-IN')}</strong><small>${escapeHtml(e.city)}</small></article><article class="stat-card"><span>Budget forecast</span><strong>${escapeHtml(money(totals.forecast))}</strong><small>Cap ${escapeHtml(money(e.budget))}</small></article><article class="stat-card"><span>Plan progress</span><strong>${pct}%</strong><small>${done} of ${tasks.length} tasks complete</small></article></div>`;
  let body='';
  if(activeView==='overview') body=`${cards}<section class="panel"><div class="panel-heading"><div><h2>${escapeHtml(e.title)}</h2><p>${escapeHtml(state.plan.summary||'Your event workspace is ready.')}</p></div><span class="pill">${escapeHtml(e.event_type)}</span></div><div class="progress-track"><span style="width:${pct}%"></span></div><h3>Next planning actions</h3>${taskRows.split('</label>').slice(0,4).join('</label>')}</section><section class="panel"><h3>Planning ideas</h3><ul>${(state.plan.ideas||[]).map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul></section>`;
  else if(activeView==='plan') body=`${cards}<section class="panel"><div class="panel-heading"><h2>Planning timeline</h2><select id="task-filter"><option value="all" ${taskFilter==='all'?'selected':''}>All tasks</option><option value="open" ${taskFilter==='open'?'selected':''}>Open</option><option value="done" ${taskFilter==='done'?'selected':''}>Completed</option></select></div>${taskRows||'<p>No tasks in this filter.</p>'}</section>`;
  else if(activeView==='budget') body=`${cards}<section class="panel"><div class="panel-heading"><h2>Budget tracker</h2><button class="button button-primary" id="add-budget-item">Add cost line</button></div><p>Forecast ${escapeHtml(money(totals.forecast))} · Headroom ${escapeHtml(money(totals.headroom))}</p><div class="table-wrap"><table><thead><tr><th>Category</th><th>Estimate</th><th>Quote</th><th>Committed</th><th>Paid</th><th></th></tr></thead><tbody>${state.budgetItems.map(x=>`<tr><td>${escapeHtml(x.category)}</td>${['estimate','quoted','committed','paid'].map(f=>`<td><input class="budget-input" data-id="${escapeHtml(x.id)}" data-field="${f}" type="number" min="0" value="${x[f]??''}"></td>`).join('')}<td><button class="remove-budget" data-id="${escapeHtml(x.id)}">Remove</button></td></tr>`).join('')}</tbody></table></div><button class="button button-quiet" id="export-budget">Export budget CSV</button></section>`;
  else if(activeView==='vendors') body=`<section class="panel"><div class="panel-heading"><h2>Vendor pipeline</h2><button class="button button-primary" data-open-vendor>Add vendor</button></div>${state.vendors.map(v=>`<article class="list-row"><div><strong>${escapeHtml(v.name)}</strong><small>${escapeHtml(v.category)} · ${escapeHtml(v.contact||'No contact added')}</small><p>${escapeHtml(v.notes||'')}</p></div><select class="vendor-status" data-id="${escapeHtml(v.id)}">${['To research','Contacted','Quote received','Shortlisted','Confirmed','Not proceeding'].map(s=>`<option ${v.status===s?'selected':''}>${s}</option>`).join('')}</select><button class="edit-vendor" data-id="${escapeHtml(v.id)}">Edit</button><button class="remove-vendor" data-id="${escapeHtml(v.id)}">×</button></article>`).join('')}</section>`;
  else if(activeView==='guests') body=`<section class="panel"><div class="panel-heading"><h2>Guest list (${state.guests.length})</h2><button class="button button-primary" data-open-guest>Add guest</button></div><input id="guest-search" type="search" placeholder="Search guests" value="${escapeHtml(guestSearch)}">${state.guests.filter(g=>g.name.toLowerCase().includes(guestSearch.toLowerCase())).map(g=>`<article class="list-row"><div><strong>${escapeHtml(g.name)}</strong><small>Party of ${g.party_size} · ${escapeHtml(g.note||'')}</small></div><select class="guest-rsvp" data-id="${escapeHtml(g.id)}">${['Invited','Pending','Attending','Declined'].map(s=>`<option ${g.rsvp===s?'selected':''}>${s}</option>`).join('')}</select><button class="remove-guest" data-id="${escapeHtml(g.id)}">×</button></article>`).join('')}<button class="button button-quiet" id="export-guests">Export guest CSV</button></section>`;
  else body=`<section class="panel"><h2>Change impact preview</h2><p>Model a proposed change before applying it. Current event data stays unchanged until you confirm.</p><form id="change-form" class="form-grid change-preview-form"><label class="field"><span>New guest target</span><input id="change-guests" type="number" min="1" max="20000" value="${Number(e.guests)}" required></label><label class="field"><span>New event date</span><input id="change-date" type="date" value="${escapeHtml(e.event_date)}" required></label><label class="field"><span>New budget cap</span><input id="change-budget" type="number" min="0" step="500" value="${Number(e.budget)}" required></label><div class="field"><span>&nbsp;</span><button class="button button-primary" type="submit">Preview impact</button></div></form>${changePreview?`<div class="impact-preview"><p><strong>Guest change:</strong> ${changePreview.guest_delta>0?'+':''}${changePreview.guest_delta} · <strong>Budget change:</strong> ${escapeHtml(money(changePreview.budget_delta))} · <strong>Estimated variable-cost movement:</strong> ${escapeHtml(money(changePreview.estimated_variable_delta))}</p><button id="apply-change" class="button button-primary">Apply update</button><button id="discard-change" class="button button-quiet">Discard</button></div>`:''}</section>`;
  appView.innerHTML=body;updateBanner();
}

// Event wiring
$('#edit-event-btn').addEventListener('click',openEventDialog);
$('#generate-plan-btn').addEventListener('click',generatePlan);
$('#mobile-menu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#export-data').addEventListener('click',exportWorkspace);
$('#dismiss-ai-banner').addEventListener('click',()=>{state.dismissBanner=true;saveState();updateBanner();});
document.querySelectorAll('.nav-item').forEach(btn=>btn.addEventListener('click',()=>setView(btn.dataset.view)));
document.body.addEventListener('click',e=>{
  const goto=e.target.closest('[data-goto]'); if(goto){e.preventDefault();setView(goto.dataset.goto);return;}
  const openVendor=e.target.closest('[data-open-vendor]');if(openVendor){openVendorDialog();return;}
  const openGuest=e.target.closest('[data-open-guest]');if(openGuest){openGuestDialog();return;}
  if(e.target.closest('#event-options')){openEventDialog();return;}
  if(e.target.closest('#add-budget-item')){const category=prompt('Cost category name:');if(category&&category.trim()){const estimate=amountNumber(prompt('Planning estimate (number only; optional):','0'))||0;state.budgetItems.push({id:uid('budget'),category:category.trim().slice(0,80),share:0,estimate,quoted:null,committed:null,paid:0,estimate_mode:'manual',icon:'◇'});logActivity('Budget line added',category.trim());saveState();render();}return;}
  if(e.target.closest('#export-budget')){exportBudget();return;}
  if(e.target.closest('#export-guests')){exportGuests();return;}
  if(e.target.closest('#print-run-sheet')){window.print();return;}
  if(e.target.closest('#discard-change')){changePreview=null;render();return;}
  if(e.target.closest('#apply-change')){if(!changePreview)return;const p=changePreview;applyEventUpdate({guests:Number(p.next.guests),event_date:p.next.date,budget:Number(p.next.budget)});return;}
  const removeBudget=e.target.closest('.remove-budget');if(removeBudget){const item=state.budgetItems.find(x=>x.id===removeBudget.dataset.id);if(item&&confirm(`Remove cost line "${item.category}"?`)){state.budgetItems=state.budgetItems.filter(x=>x.id!==item.id);logActivity('Budget line removed',item.category);saveState();render();}return;}
  const removeVendor=e.target.closest('.remove-vendor');if(removeVendor){const item=state.vendors.find(x=>x.id===removeVendor.dataset.id);if(item&&confirm(`Remove vendor lead "${item.name}"?`)){state.vendors=state.vendors.filter(x=>x.id!==item.id);saveState();render();toast('Vendor lead removed.');}return;}
  const editVendor=e.target.closest('.edit-vendor');if(editVendor){openVendorDialog(state.vendors.find(x=>x.id===editVendor.dataset.id));return;}
  const removeGuest=e.target.closest('.remove-guest');if(removeGuest){const item=state.guests.find(x=>x.id===removeGuest.dataset.id);if(item&&confirm(`Remove guest "${item.name}"?`)){state.guests=state.guests.filter(x=>x.id!==item.id);saveState();render();toast('Guest removed.');}return;}
});
appView.addEventListener('change',e=>{
  if(e.target.matches('.task-toggle')){taskToggle(e.target.dataset.task,e.target.checked);return;}
  if(e.target.matches('#task-filter')){taskFilter=e.target.value;render();return;}
  if(e.target.matches('.budget-input')){
    const item=state.budgetItems.find(x=>x.id===e.target.dataset.id);if(!item)return;
    const field=e.target.dataset.field; const val=amountNumber(e.target.value);
    if(field==='estimate'){item.estimate=val??0;item.estimate_mode='manual';}
    else item[field]=val;
    saveState();const cursor=e.target;const id=cursor.dataset.id;const fld=cursor.dataset.field;render();const newNode=document.querySelector(`.budget-input[data-id="${CSS.escape(id)}"][data-field="${CSS.escape(fld)}"]`);if(newNode){newNode.focus();newNode.setSelectionRange?.(newNode.value.length,newNode.value.length);}return;
  }
  if(e.target.matches('.vendor-status')){const v=state.vendors.find(x=>x.id===e.target.dataset.id);if(v){v.status=e.target.value;logActivity('Vendor status changed',`${v.name}: ${v.status}`);saveState();render();}return;}
  if(e.target.matches('.guest-rsvp')){const g=state.guests.find(x=>x.id===e.target.dataset.id);if(g){g.rsvp=e.target.value;logActivity('Guest RSVP updated',`${g.name}: ${g.rsvp}`);saveState();render();}return;}
});
appView.addEventListener('input',e=>{if(e.target.matches('#guest-search')){guestSearch=e.target.value;const pos=e.target.selectionStart;render();const node=$('#guest-search');if(node){node.focus();node.setSelectionRange(pos,pos);}}});

$('#event-form').addEventListener('submit',e=>{
  e.preventDefault();
  if(e.submitter?.value==='cancel'){$('#event-dialog').close();return;}
  const next={title:$('#event-title').value.trim(),event_type:$('#event-type').value,event_date:$('#event-date').value,city:$('#event-city').value.trim(),guests:Number($('#event-guests').value),budget:Number($('#event-budget').value),currency:$('#event-currency').value,preferences:$('#event-preferences').value.trim()};
  if(!next.title||!next.city||!next.event_date||next.guests<1||next.budget<0){toast('Please complete the required event details.');return;}
  $('#event-dialog').close();applyEventUpdate(next);
});
$('#vendor-form').addEventListener('submit',e=>{
  e.preventDefault();if(e.submitter?.value==='cancel'){$('#vendor-dialog').close();return;}
  const editId=$('#vendor-form').dataset.editId;
  const v={id:editId||uid('vendor'),name:$('#vendor-name').value.trim(),category:$('#vendor-category').value.trim(),status:$('#vendor-status').value,quote:amountNumber($('#vendor-quote').value),contact:$('#vendor-contact').value.trim(),notes:$('#vendor-notes').value.trim(),created_at:new Date().toISOString()};
  if(!v.name||!v.category){toast('Add the vendor name and category.');return;}
  if(editId){const idx=state.vendors.findIndex(x=>x.id===editId);if(idx>=0)state.vendors[idx]={...state.vendors[idx],...v};}else state.vendors.push(v);
  logActivity(editId?'Vendor lead updated':'Vendor lead added',`${v.name} · ${v.category}`);$('#vendor-dialog').close();saveState();render();toast(editId?'Vendor lead updated.':'Vendor lead added.');
});
$('#guest-form').addEventListener('submit',e=>{
  e.preventDefault();if(e.submitter?.value==='cancel'){$('#guest-dialog').close();return;}
  const g={id:uid('guest'),name:$('#guest-name').value.trim(),rsvp:$('#guest-rsvp').value,party_size:Number($('#guest-party').value)||1,note:$('#guest-note').value.trim(),created_at:new Date().toISOString()};
  if(!g.name||g.party_size<1){toast('Please enter a guest name and valid party size.');return;}
  state.guests.push(g);logActivity('Guest added',`${g.name} · ${g.rsvp}`);$('#guest-dialog').close();saveState();render();toast('Guest added. No invitation was sent.');
});
appView.addEventListener('submit',e=>{
  if(!e.target.matches('#change-form'))return;
  e.preventDefault();
  const next={guests:Number($('#change-guests').value),date:$('#change-date').value,budget:Number($('#change-budget').value)};
  if(!next.date||next.guests<1||next.budget<0){toast('Enter a valid date, guest target and budget cap.');return;}
  changePreview=calculateImpact(next);render();
});

async function checkHealth() {
  try {
    const r=await fetch('/.netlify/functions/health');
    if(!r.ok) return;
    const h=await r.json();
    if(h.ok && !state.dismissBanner) {
      const banner=$('#ai-status-banner');
      if(banner) {
        const strong=banner.querySelector('strong'),small=banner.querySelector('small');
        if(strong) strong.textContent='Rules-based planning is ready';
        if(small) small.textContent='Gatherly uses deterministic planning logic and a searchable 1,000-measure catalogue. No AI model or third-party AI API is used.';
      }
    }
  } catch(_) { /* Static preview: planning workspace remains available offline. */ }
}

// Netlify static hosting keeps each organizer's workspace in this browser's local storage.
async function bootGatherly() {
  render();
  setSaveStatus('Saved on this device');
  checkHealth();
}
bootGatherly();
