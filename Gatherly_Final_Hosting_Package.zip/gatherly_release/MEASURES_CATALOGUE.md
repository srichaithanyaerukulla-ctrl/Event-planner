# Gatherly 1,000-measure playbook

- Catalogue: `public/data/gatherly_measures_1000.json`
- Server-side selection: `netlify/functions/_lib/measures.mjs`
- Plan API includes `recommended_measures` (up to 12) and `measure_catalogue` metadata.
- Frontend: `public/measures.js` provides search, domain filtering and event-specific recommendations.
- Domains include budgeting, venue readiness, catering, accessibility, safety, timelines, vendor coordination, guest communications, weather, transport, decor, AV, privacy, sustainability, staffing, wedding-specific coordination, birthday experiences, community operations, children/family needs, allergen safeguards, registration, communications, finance, contingencies and permissions.

Each entry has a stable ID, applicable event type, scenario trigger, action, rationale, priority, planning stage and verification instruction. Recommendations are prompts for organizers to validate, not claims that a task is complete or that local requirements have been satisfied.
