# Gatherly Full-Stack Build Status

## Delivered in this package

- Responsive frontend for overview, plan/timeline, budget, vendors, guests, and change-impact preview.
- FastAPI backend serves the frontend and exposes `/api/health`, `/api/plan`, and `/api/workspace`.
- Gemini integration is server-side and controlled by `GEMINI_API_KEY`.
- Guided deterministic fallback keeps the planning workflow usable without a Gemini key.
- SQLite persistence stores one shared demo workspace for this app deployment.
- Browser `localStorage` is retained as a recovery cache and local fallback.
- Windows one-click launcher: `run_gatherly_windows.bat`.

## Verification

Run the automated tests with:

```bash
python -m pip install -r requirements.txt
python -m pip install pytest httpx
python -m pytest -q
```

The package should not be described as production-ready or multi-user. It has no authentication, per-user authorization, or collaboration support. The single demo workspace is shared by all visitors to the same deployment.

## Before public deployment

1. Add authentication and per-user workspace authorization.
2. Add rate limiting and request logging with secret redaction.
3. Configure HTTPS, secret storage, database backup, and retention/deletion controls.
4. Verify Gemini model access and quota using your own API key.
5. Test with synthetic event data before inviting real users.
