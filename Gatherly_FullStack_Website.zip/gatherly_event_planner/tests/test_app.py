from datetime import date

from fastapi.testclient import TestClient

from app import PlanRequest, _fallback_plan, app

client = TestClient(app)


def test_fallback_plan_has_actionable_structure():
    brief = PlanRequest(
        event_type="birthday",
        title="Mira's Birthday",
        event_date=date(2027, 1, 16),
        city="Hyderabad",
        guests=24,
        budget=50000,
        currency="INR",
        preferences="simple, accessible, vegetarian options",
        priorities=["guest experience"],
    )
    plan = _fallback_plan(brief)
    assert plan["generation_mode"] == "guided-demo"
    assert len(plan["tasks"]) >= 8
    assert len(plan["ideas"]) >= 3
    assert plan["vendor_categories"]
    assert all(0 <= task["days_before"] <= 180 for task in plan["tasks"])


def test_health_endpoint_is_available():
    response = client.get("/api/health")
    assert response.status_code == 200
    payload = response.json()
    assert payload["ok"] is True
    assert payload["app"] == "Gatherly"


def test_plan_endpoint_works_without_api_key(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    response = client.post("/api/plan", json={
        "event_type": "community",
        "title": "Neighborhood Day",
        "event_date": "2027-01-16",
        "city": "Hyderabad",
        "guests": 100,
        "budget": 100000,
        "currency": "INR",
        "preferences": "inclusive and low-waste",
        "priorities": ["budget clarity"],
    })
    assert response.status_code == 200
    payload = response.json()
    assert payload["generation_mode"] == "guided-demo"
    assert isinstance(payload["tasks"], list)


def test_invalid_plan_request_is_rejected():
    response = client.post("/api/plan", json={
        "event_type": "festival",
        "title": "Bad Event",
        "event_date": "not-a-date",
        "city": "A",
        "guests": 0,
        "budget": -1,
        "currency": "rupees",
    })
    assert response.status_code == 422


def test_root_serves_the_application():
    response = client.get("/")
    assert response.status_code == 200
    assert "Gatherly" in response.text
    assert "/static/app.js" in response.text


def test_workspace_api_persists_state(tmp_path, monkeypatch):
    import app as app_module

    monkeypatch.setattr(app_module, "DB_PATH", tmp_path / "test-gatherly.db")
    app_module._init_database()
    payload = {"event": {"title": "Persisted Demo"}, "guests": [{"id": "g-1", "name": "Guest"}]}
    saved = client.put("/api/workspace", json={"state": payload})
    assert saved.status_code == 200
    assert saved.json()["ok"] is True

    loaded = client.get("/api/workspace")
    assert loaded.status_code == 200
    assert loaded.json()["state"] == payload
    assert loaded.json()["updated_at"]


def test_workspace_rejects_non_object_state():
    response = client.put("/api/workspace", json={"state": ["not", "an", "object"]})
    assert response.status_code == 422
