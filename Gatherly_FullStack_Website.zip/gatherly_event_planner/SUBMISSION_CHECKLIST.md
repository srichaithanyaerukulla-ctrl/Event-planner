# PromptWars Virtual — Submission Checklist

Use this as a practical checklist. Confirm the live portal's currently active rules and deadline before submitting.

## Product demo (3 minutes)

- [ ] Start with the challenge problem: event details, timelines, budget, vendor checklist, and personalized ideas are otherwise spread across different tools.
- [ ] Create or edit a community event and generate a plan.
- [ ] Show the plan timeline, check one task complete, and explain how deadlines follow the event date.
- [ ] Open the budget ledger. Change an estimate, add a quote, then explain the committed → quoted → estimated forecast rule.
- [ ] Add one vendor lead and show status/quote notes; explicitly state that the app does not invent vendor availability.
- [ ] Add a guest and update RSVP. Clarify that no invite is sent and the demo list is stored in the app server shared workspace.
- [ ] Open Change impact, increase guest count and move the date; show a preview before applying.
- [ ] Export budget CSV or print the run sheet.
- [ ] Show the app in a clean browser and confirm the deployment works without developer-only state.

## Technical submission

- [ ] Put source in a public or otherwise organizer-accessible Git repository, according to portal rules.
- [ ] Deploy the app and provide a working live preview URL.
- [ ] Add setup instructions and disclose which parts need `GEMINI_API_KEY`.
- [ ] Run and record regression tests.
- [ ] Add screenshots / short demo video if accepted by the portal.
- [ ] Never publish a `.env` file or API key.

## Build-in-public narrative

- [ ] Capture the actual prompts used in Google Antigravity and the code changes they produced.
- [ ] Share what failed, what you learned, and how the product changed—do not fabricate a build journey or user-test results.
- [ ] Explain the key design decision: AI generates editable ideas and tasks; deterministic code computes budgets; the organizer approves consequential changes.
- [ ] Include the live preview and code repository links.
- [ ] Verify any required technical blog / LinkedIn post and submission form fields in the active challenge portal.

## Known gaps to disclose

- Persistence uses one shared SQLite workspace per deployment; there are no accounts, per-user isolation, or multi-user collaboration. Keep the demo private and use synthetic guest data.
- Vendor data is manual; no live marketplace or real-time availability check.
- No outbound email/WhatsApp, calendar writes, booking, contracts, or payments.
- Budget splits are illustrative and must be replaced with real, sourced quotes.
- Live GenAI requires the operator's server-side Gemini API key and access to the selected model.
