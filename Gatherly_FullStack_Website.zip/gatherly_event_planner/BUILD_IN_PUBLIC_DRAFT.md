# Build-in-Public Narrative — Draft to Finalize After Your Antigravity Session

> **Important:** This is a submission draft, not evidence that the Antigravity build session or deployment has already happened. Replace all bracketed fields with your real prompts, tests, screenshots and links. Do not publish claims you have not verified.

## LinkedIn post draft

**I’m building Gatherly: an event-planning copilot that keeps plans useful when real life changes.**

The Celebration & Event Planner challenge looks simple at first: generate ideas, make a checklist, and split the budget. But the hardest part of planning a wedding, birthday or community event is keeping those pieces connected as guest counts, dates, quotes and priorities change.

I focused Gatherly on three practical principles:

- **AI drafts; the organizer decides.** The planner suggests ideas, tasks and vendor categories, but the user can edit the plan and must approve a proposed change.
- **Budget math stays deterministic.** Each cost line keeps estimate, quote, commitment and paid amounts separate. The forecast uses one basis per line to avoid double-counting.
- **Changes are visible before they are applied.** A change-impact preview flags likely budget and schedule consequences when the guest count, event date or budget cap changes.

The current prototype includes an event workspace, editable timeline, budget ledger, vendor tracker, guest RSVP list, change-impact preview, CSV exports and a printable run sheet. When configured, the AI plan is generated through a server-side Gemini connection; without a key, the app remains usable in a clearly labelled guided-demo mode.

**What I tested:** [insert the actual test cases, results and screenshots from your Antigravity session].

**What is not solved yet:** [state the true limitations you verified]. The prototype does not invent vendor quotes or availability, and it does not send invitations, book services or spend money.

**Build notes:** [briefly describe one real prompt iteration, one failure, and what changed].

Live preview: [insert deployed URL after deployment]  
Source code: [insert repository URL]  
Technical notes: [insert blog URL, if required]

#BuildInPublic #AIEngineering #PromptWars #EventPlanning

## Technical blog outline

1. **Problem framing:** the planning-coordination gap behind the challenge brief.
2. **Product decision:** why a change-aware workspace is more useful than a one-shot idea generator.
3. **Architecture:** responsive client, FastAPI plan endpoint, Gemini structured output, deterministic budget ledger, local demo persistence.
4. **Prompt contract:** event brief as data; schema-constrained tasks, ideas, categories and risks; no invented vendor facts or prices.
5. **Evaluation:** show real test cases, including missing API key, invalid request, headcount change, date shift, budget overrun and an instruction-injection string.
6. **Trade-offs and limitations:** no authentication, shared database, live vendor availability, messaging, payments or booking flows in the prototype.
7. **What changed during the build:** a truthful timeline of actual Antigravity prompts, test outcomes and decisions.
8. **Try it:** live preview and source links.
