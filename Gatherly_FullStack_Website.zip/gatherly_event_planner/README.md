# Gatherly — Event Planning, with More Clarity

A full-stack, mobile-first MVP for the PromptWars Virtual **Celebration & Event Planner** challenge. Gatherly turns an event brief into an editable task timeline, budget ledger, vendor tracker, guest roster, and change-impact preview. The FastAPI backend serves the frontend, generates AI plans, and persists the workspace in SQLite.

> **MVP status:** integrated full-stack prototype / challenge submission starter. FastAPI serves the responsive frontend, exposes planning and workspace APIs, and stores one shared demo workspace in SQLite. Live GenAI uses a server-side Gemini API key; without a key the app uses clearly labelled deterministic demo templates. This is not production-ready: there is no login or per-user data isolation, and external messages/bookings/payments are intentionally not automated.

## What works

- Event setup for weddings, birthdays, and community events.
- Personalized plan generation through Gemini when configured, with a dependable guided fallback.
- Editable timeline tasks with due dates recalculated from the event date, completion state, and printable run sheet.
- Budget ledger that keeps estimate, quote, commitment, and paid amounts separate. Each line contributes only one number to the forecast: committed → quoted → estimated.
- Vendor leads and quote/status notes. No vendor names, quotes, reviews, or live availability are invented.
- Guest roster with party size and RSVP status. No messages are sent.
- Change-impact preview for guest count, date, and budget cap; a scenario must be explicitly applied. Quotes and commitments are not silently altered.
- CSV export for the budget and guest list; JSON workspace backup.
- Server-side workspace persistence using SQLite, with browser `localStorage` as a recovery cache.

## Run locally

Requirements: Python 3.11+ (Python 3.12 recommended).

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1

pip install -r requirements.txt
cp .env.example .env   # optional; configure your key in the shell or deployment secret settings
uvicorn app:app --reload --port 8000
```

Open <http://127.0.0.1:8000>.

### Enable live GenAI

1. Create an API key in Google AI Studio.
2. Set the key as a **server environment variable**; do not paste it into `static/app.js`, HTML, a public repository, or a browser prompt.

```bash
# macOS / Linux
export GEMINI_API_KEY="your-key"
export GEMINI_MODEL="gemini-3.8-flash"
uvicorn app:app --reload --port 8000
```

```powershell
# Windows PowerShell
$env:GEMINI_API_KEY="your-key"
$env:GEMINI_MODEL="gemini-3.8-flash"
uvicorn app:app --reload --port 8000
```

The application loads a local `.env` file when present, and environment variables from the deployment host take precedence. SQLite data is stored in `data/gatherly.db` by default; set `GATHERLY_DB_PATH` to select another writable path. The health endpoint `/api/health` shows whether server-side AI is enabled. Gemini generation is schema-constrained and validated in the backend. When AI is disabled or unavailable, the endpoint returns a deterministic plan and the UI identifies it as guided demo mode. Check current model access, quota, billing, and API terms before a public deployment.

## Full-stack data flow

1. The browser loads `/` from FastAPI and requests `/api/workspace`.
2. FastAPI loads the shared demo workspace from SQLite. If no server copy exists, the browser's local recovery copy is uploaded.
3. User edits are saved immediately to `localStorage` and debounced to `PUT /api/workspace` for server persistence.
4. `POST /api/plan` sends only the event brief to the Gemini API when configured. Guest records and vendor notes are not included.
5. `/api/health` reports API health, whether Gemini is configured, the selected model, and persistence type.

**Demo limitation:** This release has one shared workspace per app deployment and no login. Anyone who can access the deployment can read or overwrite that workspace. Keep it private or add authentication, per-user workspace IDs, authorization, and database migrations before a public pilot.

## Deployment notes

The included `Dockerfile` is a portable starting point for a container host that supports secrets and HTTPS.

- Set `GEMINI_API_KEY` using the host's secret manager; never bake it into the image.
- Set `PORT` if required by the host.
- Pin and review dependencies before a public release.
- Use a managed database and proper authentication before multiple people need to share plans.
- When live AI is enabled, the event brief (event type/title/date/city, guest target, budget cap, preferences and priorities) is sent to Google Gemini for plan generation; the guest roster and vendor notes are not sent by the plan endpoint. The current prototype has single-workspace SQLite persistence but does not have authentication, per-user tenancy, collaboration, notification sending, payments, or a booking integration. The workspace endpoint is intentionally unauthenticated for a controlled demo; do not expose it publicly with real guest data. Do not represent these as implemented.
- For a real pilot, add automated migrations, logging/error monitoring, rate limiting, account/object authorization, backup/restore, data retention/deletion, consent and privacy notices, and a security review.

## Technical design

- `static/index.html`: accessible layout and dialogs.
- `static/styles.css`: responsive interface, mobile layout, and print styles.
- `static/app.js`: client state, timeline, budget math, exports, change preview, local recovery cache, and debounced server sync.
- `app.py`: FastAPI server, Gemini adapter, schema validation, deterministic fallback, SQLite workspace persistence, and health endpoint.
- `PROMPTS_AND_EVALUATION.md`: prompting approach and evaluation plan.
- `SUBMISSION_CHECKLIST.md`: challenge evidence and demo checklist.

The product deliberately avoids a marketplace-first approach. Vendor research is a lead/checklist workflow until reliable sources, vendor verification, operational support, and legal responsibilities exist.

## Core product principles

1. **No invented reality.** AI can suggest ideas and tasks, but vendor availability, quote amounts, policies, reviews, and confirmed bookings need a real source.
2. **Deterministic money math.** The application computes forecasts; a line uses only one forecast basis to prevent estimate + quote + commitment double-counting.
3. **Human approval for side effects.** The app does not send invites, book vendors, change external calendars, or spend money.
4. **Show assumptions.** Budget allocations are editable planning splits, not local-market research or guaranteed cost estimates.
5. **Protect guest data.** The unauthenticated demo stores guest/vendor data in a shared SQLite workspace. Use synthetic data only until authentication and per-user access controls are implemented. Export files may also contain private details; store and share carefully.

## License / originality

This source is a fresh prototype. Before submission, confirm third-party asset and package licenses, keep the project's actual prompt/build history, and follow the event's originality and AI-use rules. Do not claim that a preview deployment, user testing, model integration, or Antigravity workflow happened unless you have actually done it.
