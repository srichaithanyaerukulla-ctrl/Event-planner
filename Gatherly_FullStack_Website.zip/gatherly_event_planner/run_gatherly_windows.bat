@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  set PY=py -3
) else (
  set PY=python
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  %PY% -m venv .venv
  if errorlevel 1 goto :error
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto :error
echo.
echo Starting Gatherly at http://127.0.0.1:8000
echo Press Ctrl+C to stop the server.
python -m uvicorn app:app --host 127.0.0.1 --port 8000
exit /b 0
:error
echo Setup failed. Confirm Python 3.11+ is installed and internet access is available.
pause
exit /b 1
