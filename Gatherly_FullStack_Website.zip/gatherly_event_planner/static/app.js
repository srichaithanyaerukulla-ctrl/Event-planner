'use strict';

const STORE_KEY = 'gatherly-event-planner-v1';
const todayISO = () => new Date().toLocaleDateString('en-CA');
const defaultEvent = {
  title: 'Community Connect Day', event_type: 'community', event_date: '2027-01-16', city: 'Hyderabad',
  guests: 120, budget: 180000, currency: 'INR', preferences: 'Warm, welcoming, accessible, low-waste',
  priorities: ['budget clarity', 'guest experience']
};
const budgetBlueprint = [
  {category:'Venue', share:0.22, icon:'⌂'},
  {category:'Food & refreshments', share:0.32, icon:'♨'},
  {category:'Decor & signage', share:0.10, icon:'✳'},
  {category:'Photo / video', share:0.08, icon:'▣'},
  {category:'AV & activities', share:0.07, icon:'♫'},
  {category:'Transport & logistics', share:0.06, icon:'↗'},
  {category:'Supplies & cleanup', share:0.05, icon:'◇'},
  {category:'Contingency reserve', share:0.10, icon:'⌁'}
];
const defaultVendors = [
  {id:'v-venue', name:'Venue to research', category:'Venue', status:'To research', quote:null, contact:'', notes:'Confirm capacity, access window, accessibility, taxes and cancellation terms.', created_at:new Date().toISOString()},
  {id:'v-food', name:'Catering options', category:'Food & refreshments', status:'To research', quote:null, contact:'', notes:'Ask for per-person inclusions, dietary options, taxes and final-headcount deadline.', created_at:new Date().toISOString()},
  {id:'v-av', name:'AV / activity support', category:'AV and activities', status:'Contacted', quote:null, contact:'', notes:'Confirm equipment, setup time, power/network requirements and an on-site contact.', created_at:new Date().toISOString()}
];

function uid(prefix='id') { return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`; }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function amountNumber(value) { if (value === '' || value === null || value === undefined) return null; const n = Number(value); return Number.isFinite(n) && n >= 0 ? n : null; }
function money(value, currency=state.event.currency) {
  const n = Number(value || 0);
  try { return new Intl.NumberFormat('en-IN', {style:'currency', currency, maximumFractionDigits:0}).format(n); }
  catch { return `${currency} ${Math.round(n).toLocaleString('en-IN')}`; }
}
function shortMoney(value) {
  const n = Number(value || 0), symbol = state.event.currency === 'INR' ? '₹' : `${state.event.currency} `;
  if (Math.abs(n) >= 10000000) return `${symbol}${(n/10000000).toFixed(1)}Cr`;
  if (Math.abs(n) >= 100000) return `${symbol}${(n/100000).toFixed(1)}L`;
  if (Math.abs(n) >= 1000) return `${symbol}${(n/1000).toFixed(1)}k`;
  return `${symbol}${Math.round(n).toLocaleString('en-IN')}`;
}
function dateObj(iso) { if (!iso) return new Date(); return new Date(`${iso}T12:00:00`); }
function addDaysISO(iso, days) { const d = dateObj(iso); d.setDate(d.getDate()+Number(days||0)); return d.toLocaleDateString('en-CA'); }
function dateLabel(iso, opts={day:'numeric', month:'short'}) { if (!iso) return 'Not set'; return new Intl.DateTimeFormat('en-IN', opts).format(dateObj(iso)); }
function dayDiff(fromIso, toIso) { return Math.round((dateObj(toIso) - dateObj(fromIso))/86400000); }
function daysToEvent() { return dayDiff(todayISO(), state.event.event_date); }
function initials(name) { return String(name||'G').trim().split(/\s+/).slice(0,2).map(s=>s[0]||'').join('').toUpperCase(); }
function forecastFor(item) {
  if (item.committed !== null && item.committed !== undefined && item.committed !== '') return Number(item.committed)||0;
  if (item.quoted !== null && item.quoted !== undefined && item.quoted !== '') return Number(item.quoted)||0;
  return Number(item.estimate)||0;
}
function budgetTotals() {
  const forecast = state.budgetItems.reduce((a,x)=>a+forecastFor(x),0);
  const estimate = state.budgetItems.reduce((a,x)=>a+(Number(x.estimate)||0),0);
  const quoted = state.budgetItems.reduce((a,x)=>a+(x.quoted!==null && x.quoted!=='' ? Number(x.quoted)||0 : 0),0);
  const committed = state.budgetItems.reduce((a,x)=>a+(x.committed!==null && x.committed!=='' ? Number(x.committed)||0 : 0),0);
  const paid = state.budgetItems.reduce((a,x)=>a+(Number(x.paid)||0),0);
  return {forecast, estimate, quoted, committed, paid, headroom:Number(state.event.budget)-forecast};
}
function budgetItemDefaults(cap) {
  return budgetBlueprint.map((b,i)=>({id:`budget-${i+1}`,category:b.category,share:b.share,estimate:Math.round(Number(cap||0)*b.share),quoted:null,committed:null,paid:0,estimate_mode:'allocation',icon:b.icon}));
}
function localPlan(event) {
  const type = event.event_type;
  let theme, ideas, vendor_categories;
  const base = [
    [60,'Lock the venue shortlist','Confirm capacity, accessibility, included facilities, setup window and cancellation terms.','Venue','high'],
    [45,'Request comparable vendor quotes','Use the same brief for each vendor and compare inclusions, taxes, deposits and exclusions.','Vendors','high'],
    [30,'Confirm the event format','Agree on the running order, theme, key moments and the decision-maker for each area.','Planning','medium'],
    [21,'Send invitations','Share the essentials, an RSVP deadline and a clear contact route for access or dietary requests.','Guests','high'],
    [14,'Review RSVPs and quantities','Compare responses with the guest target and ask vendors how late changes affect pricing.','Guests','high'],
    [10,'Approve final vendor scope','Confirm deliverables, service timings, payment milestones and the responsible contact.','Vendors','high'],
    [7,'Walk through event-day operations','Assign owners, arrival times, setup tasks, emergency contacts and contingency actions.','Operations','high'],
    [3,'Reconfirm critical details','Reconfirm venue access, vendor arrival, final headcount and the backup plan.','Operations','high'],
    [1,'Prepare the event-day run sheet','Keep the latest schedule, contact list and open decisions available offline.','Operations','high'],
    [0,'Run the event and capture actuals','Track important changes, settle approved invoices and record lessons after the event.','Event day','medium']
  ];
  if(type==='birthday') {
    theme='A personal, joyful celebration';
    ideas=['Choose one signature moment: a memory wall, short toast or collaborative wish board.','Offer two or three activity choices rather than overfilling the schedule.','Use reusable signage and decor that can be borrowed or reused afterwards.','Keep a quiet seating area and a simple plan for children or older guests, if relevant.'];
    vendor_categories=['Venue or home setup','Food and cake','Decoration','Photography','Music or activities','Transport / cleanup'];
  } else if(type==='wedding') {
    theme='A guest-first wedding celebration';
    ideas=['Design the day around clear transitions between ceremony, photographs, food and celebration.','Create a single list of key moments and the person responsible for each.','Keep a private reserve for weather, transport, guest and vendor changes.','Share a clear arrival guide and accessibility information with guests in advance.'];
    vendor_categories=['Venue','Catering','Decor and florals','Photo / video','Sound / lighting','Transport','Attire / makeup','Ceremony services'];
    base.unshift([90,'Map functions and decision owners','List each function, location, key traditions and who is authorized to approve changes.','Planning','high']);
  } else {
    theme='An inclusive, easy-to-navigate community gathering';
    ideas=['Provide a simple arrival/check-in flow and clear directional signage.','Set up a host or volunteer roster with one named owner per activity.','Choose activities that work for different energy levels and mobility needs.','Publish the schedule, venue access details and contact point in one shareable place.'];
    vendor_categories=['Venue','Food / refreshments','AV and internet','Signage','Activities / speakers','Volunteer support','Waste / cleanup'];
  }
  const tasks = base.sort((a,b)=>b[0]-a[0]).map(([days_before,title,detail,category,priority])=>({id:uid('task'),days_before,title,detail,category,priority}));
  return {theme,summary:`A practical first draft for ${event.title}. Treat every cost as a planning assumption until a vendor confirms it in writing.`,ideas,tasks,vendor_categories,risks:['Treat budget allocations as editable planning assumptions, not market quotes.','Confirm venue capacity, vendor availability, tax treatment and cancellation terms directly.','Re-check task dates if the event date changes; approve changes before applying them.'],generation_mode:'guided-demo'};
}
function createInitialState() {
  const event = {...defaultEvent};
  const plan = localPlan(event);
  return {event,plan,budgetItems:budgetItemDefaults(event.budget),vendors:defaultVendors.map(v=>({...v,id:uid('vendor')})),guests:[],completedTasks:[],activity:[{id:uid('activity'),title:'Workspace created',detail:'Starter plan loaded in guided demo mode.',at:new Date().toISOString()}],lastSaved:new Date().toISOString(),dismissBanner:false};
}
function normalizeState(raw) {
  const initial=createInitialState();
  if(!raw || typeof raw!=='object') return initial;
  const merged={...initial,...raw};
  merged.event={...defaultEvent,...(raw.event||{})};
  if(!Array.isArray(merged.budgetItems)) merged.budgetItems=budgetItemDefaults(merged.event.budget);
  if(!Array.isArray(merged.vendors)) merged.vendors=[];
  if(!Array.isArray(merged.guests)) merged.guests=[];
  if(!Array.isArray(merged.completedTasks)) merged.completedTasks=[];
  if(!Array.isArray(merged.activity)) merged.activity=[];
  if(!merged.plan || !Array.isArray(merged.plan.tasks)) merged.plan=localPlan(merged.event);
  merged.plan.tasks=merged.plan.tasks.map(t=>({...t,id:t.id||uid('task')}));
  merged.budgetItems=merged.budgetItems.map((item,i)=>({...item,id:item.id||uid('budget'),share:Number(item.share)||0,estimate:Number(item.estimate)||0,quote:null,...item}));
  return merged;
}
let state;
let cachedLocalState=null;
try { cachedLocalState=JSON.parse(localStorage.getItem(STORE_KEY)||'null'); state=normalizeState(cachedLocalState); }
catch { state=createInitialState(); cachedLocalState=null; }
let activeView='overview';
let taskFilter='all';
let guestSearch='';
let toastTimer=null;
let changePreview=null;

const viewTitles={overview:['Make room for the moment.','The moving parts, in one calm place.'],plan:['A plan that keeps its promises.','Small, clear steps from now until event day.'],budget:['Know where every rupee goes.','Planning assumptions, real quotes and commitments—kept separate.'],vendors:['A clearer way to compare vendors.','Track conversations and compare like-for-like, without inventing facts.'],guests:['Every guest detail, thoughtfully organized.','Keep your RSVP picture clear and your guest data private.'],change:['When plans change, see what moves.','Preview downstream effects before you apply an update.']};
const $=sel=>document.querySelector(sel);
const appView=$('#app-view');

let serverSaveTimer=null;
let serverSaveChain=Promise.resolve();
let serverSyncFailed=false;
function setSaveStatus(label,warning=false) {
  const node=$('#save-status');
  if(!node)return;
  node.innerHTML=`<span class="status-dot"${warning?' style="background:#d9a37d"':''}></span> ${escapeHtml(label)}`;
}
function queueServerSave() {
  clearTimeout(serverSaveTimer);
  setSaveStatus('Sync pending');
  serverSaveTimer=setTimeout(()=>{
    const snapshot=JSON.parse(JSON.stringify(state));
    serverSaveChain=serverSaveChain.then(async()=>{
      setSaveStatus('Syncing to server…');
      const response=await fetch('/api/workspace',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({state:snapshot})});
      if(!response.ok)throw new Error(`Workspace sync failed (${response.status})`);
      serverSyncFailed=false;
      if(snapshot.lastSaved===state.lastSaved)setSaveStatus('Saved to server');
    }).catch(()=>{
      serverSyncFailed=true;
      setSaveStatus('Saved on this device',true);
    });
  },450);
}
function saveState(message='Saved to server') {
  try {
    state.lastSaved=new Date().toISOString();
    localStorage.setItem(STORE_KEY,JSON.stringify(state));
    setSaveStatus(message==='Saved to server'?'Sync pending':message);
    queueServerSave();
  } catch(e) {
    setSaveStatus('Local storage unavailable',true);
    toast('Could not save locally. Export a backup before refreshing.');
    queueServerSave();
  }
}
function logActivity(title,detail) {
  state.activity.unshift({id:uid('activity'),title,detail,at:new Date().toISOString()});
  state.activity=state.activity.slice(0,30);
}
function toast(msg) {
  const node=$('#toast'); node.textContent=msg; node.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>node.classList.remove('show'),2800);
}
function updateBanner() {
  const banner=$('#ai-status-banner');
  if(state.dismissBanner){banner.classList.add('hidden');return;}
  banner.classList.remove('hidden');
  if(state.plan.generation_mode==='gemini') {
    banner.classList.add('live');
    banner.querySelector('strong').textContent='Live GenAI plan generated';
    banner.querySelector('small').textContent='Personalized draft from Gemini. The event brief was sent to Google; guest and vendor records were not. Review every suggestion before acting.';
  } else if(state.plan.generation_mode==='guided-demo') {
    banner.classList.remove('live');
    banner.querySelector('strong').textContent='Guided demo mode';
    banner.querySelector('small').textContent='Connect a Gemini API key on the server for personalized live AI planning. You can still test the full workflow here.';
  }
}
function setView(view) {
  if(!viewTitles[view]) return;
  activeView=view;
  render();
  $('#sidebar').classList.remove('open');
  window.scrollTo({top:0,behavior:'smooth'});
}
function setPageMeta() {
  const [title,subtitle]=viewTitles[activeView];
  $('#page-title').textContent=title; $('#page-subtitle').textContent=subtitle; $('#breadcrumb-title').textContent=activeView==='plan'?'Plan & timeline':activeView==='change'?'Change impact':activeView==='guests'?'Guest list':activeView.charAt(0).toUpperCase()+activeView.slice(1);
  document.title=`${viewTitles[activeView][0]} — Gatherly`;
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.toggle('active',n.dataset.view===activeView));
  $('#nav-task-count').textContent=state.plan.tasks.length;
  $('#edit-event-btn').classList.toggle('hidden',activeView==='change');
  $('#generate-plan-btn').classList.toggle('hidden',activeView==='budget'||activeView==='vendors'||activeView==='guests');
}
function render() {
  setPageMeta(); updateBanner();
  const viewRenders={overview:renderOverview,plan:renderPlan,budget:renderBudget,vendors:renderVendors,guests:renderGuests,change:renderChange};
  appView.innerHTML=viewRenders[activeView]();
}
function taskDate(task) { return addDaysISO(state.event.event_date,-Number(task.days_before||0)); }
function dueLabel(task) {
  const due=taskDate(task), delta=dayDiff(todayISO(),due);
  if(delta===0) return 'Due today';
  if(delta<0) return `Overdue · ${Math.abs(delta)}d`;
  return `Due ${dateLabel(due)}`;
}
function relativeDeadline() { const d=daysToEvent(); if(d<0)return `${Math.abs(d)} days since event`; if(d===0)return 'Today'; if(d===1)return 'Tomorrow'; return `In ${d} days`; }
function categoryShort(cat) { return String(cat||'Planning').toLowerCase(); }
function eventTypeLabel(type) { return ({wedding:'WEDDING',birthday:'BIRTHDAY',community:'COMMUNITY EVENT'})[type]||String(type).toUpperCase(); }
function taskRow(task,compact=true) {
  const done=state.completedTasks.includes(task.id);
  return `<div class="task-row"><input type="checkbox" class="task-check task-toggle" data-task="${escapeHtml(task.id)}" ${done?'checked':''} aria-label="Mark ${escapeHtml(task.title)} ${done?'incomplete':'complete'}"><div><div class="task-title ${done?'completed':''}">${escapeHtml(task.title)}</div><div class="task-meta"><span><span class="priority-dot priority-${escapeHtml(task.priority||'medium')}"></span>${escapeHtml(task.category||'Planning')}</span><span>·</span><span>${escapeHtml(done?'Completed':dueLabel(task))}</span></div></div><span class="pill ${done?'pill-green':(task.priority==='high'?'pill-peach':'pill-gray')}">${done?'Done':escapeHtml(task.priority||'medium')}</span></div>`;
}
function statCard(label,value,foot,icon,color='green') {
  return `<article class="stat-card"><div class="stat-head"><span>${escapeHtml(label)}</span><span class="stat-icon ${color}">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-foot">${foot}</div></article>`;
}
function renderOverview() {
  const totals=budgetTotals();
  const done=state.plan.tasks.filter(t=>state.completedTasks.includes(t.id)).length;
  const completion=state.plan.tasks.length?Math.round(done/state.plan.tasks.length*100):0;
  const outstanding=state.plan.tasks.filter(t=>!state.completedTasks.includes(t.id)).sort((a,b)=>b.days_before-a.days_before).slice(0,4);
  const rsvp=state.guests.reduce((a,g)=>a+(g.rsvp==='Attending'?Number(g.party_size||1):0),0);
  const items=state.budgetItems.slice().sort((a,b)=>forecastFor(b)-forecastFor(a)).slice(0,5);
  return `
    <section class="overview-hero">
      <article class="event-card"><div class="event-card-top"><span class="event-type-tag">${eventTypeLabel(state.event.event_type)}</span><button class="event-options" id="event-options" aria-label="Edit event">•••</button></div><div class="event-orb" aria-hidden="true"></div><h2>${escapeHtml(state.event.title)}</h2><p>${escapeHtml(state.event.city)} · Made for good people and a great moment.</p><div class="event-meta"><span>▣ <b>${dateLabel(state.event.event_date,{day:'numeric',month:'long',year:'numeric'})}</b></span><span>♙ <b>${Number(state.event.guests).toLocaleString('en-IN')} guests planned</b></span><span>◎ <b>${relativeDeadline()}</b></span></div><div class="event-bottom"><div class="event-progress"><div class="event-progress-line"><span>Planning progress</span><span>${done} of ${state.plan.tasks.length} tasks · ${completion}%</span></div><div class="progress-track"><div class="progress-fill" style="width:${completion}%"></div></div></div><button class="event-edit" data-goto="plan">Open plan ↗</button></div></article>
      <article class="next-card"><div><div class="card-topline"><span class="card-kicker">NEXT UP</span><span class="tiny-icon">↗</span></div><h3>${outstanding.length?escapeHtml(outstanding[0].title):'Your plan is up to date'}</h3><p>${outstanding.length?escapeHtml(outstanding[0].detail):'Review your plan and confirm any remaining details.'}</p></div><div class="next-date-row"><div class="date-badge"><small>${dateLabel(taskDate(outstanding[0]||{days_before:0}),{month:'short'}).toUpperCase().slice(0,3)}</small><strong>${dateLabel(taskDate(outstanding[0]||{days_before:0}),{day:'numeric'})}</strong></div><div class="next-date-copy"><strong>${outstanding.length?escapeHtml(dueLabel(outstanding[0])):'No open tasks'}</strong><small>${outstanding.length?`${escapeHtml(outstanding[0].category)} · ${escapeHtml(outstanding[0].priority)} priority`:'Add new tasks when needed'}</small></div></div></article>
    </section>
    <section class="grid grid-4">
      ${statCard('Planning forecast',shortMoney(totals.forecast),`Cap: <strong>${shortMoney(state.event.budget)}</strong>`,'₹','green')}
      ${statCard('Tasks completed',`${done} <span style="font-size:12px;color:#9aa69f;font-weight:600">/ ${state.plan.tasks.length}</span>`,`${completion}% of plan complete`,'✓','blue')}
      ${statCard('Vendor leads',String(state.vendors.length),`${state.vendors.filter(v=>v.status==='Quote received'||v.status==='Shortlisted'||v.status==='Confirmed').length} with quote / shortlist / confirmation`,'◇','peach')}
      ${statCard('RSVPs attending',String(rsvp),`${state.guests.length} guest records · target ${Number(state.event.guests).toLocaleString('en-IN')}`,'♙','yellow')}
    </section>
    <section class="overview-lower">
      <article class="panel"><div class="section-head"><div><h2>Up next on your list</h2><p>Four tasks to keep the plan moving.</p></div><button class="link-button" data-goto="plan">View timeline →</button></div><div class="task-list">${outstanding.length?outstanding.map(t=>taskRow(t)).join(''):`<div class="empty-state"><div class="empty-icon">✓</div><h3>All tasks complete</h3><p>Generate a refreshed plan if your event details change.</p></div>`}</div></article>
      <article class="panel"><div class="section-head"><div><h2>Budget snapshot</h2><p>Planning allocation guide · not vendor quotes.</p></div><button class="link-button" data-goto="budget">Details →</button></div><div class="mini-budget-header"><div><div class="card-kicker">CURRENT FORECAST</div><div class="mini-budget-total">${shortMoney(totals.forecast)} <small>/ ${shortMoney(state.event.budget)}</small></div></div><span class="pill ${totals.headroom<0?'pill-peach':'pill-green'}">${totals.headroom<0?'Over cap':`${Math.round((totals.forecast/Math.max(1,state.event.budget))*100)}% allocated`}</span></div><div class="budget-meter">${items.map((x,i)=>`<span style="width:${Math.max(1,forecastFor(x)/Math.max(1,totals.forecast)*100)}%"></span>`).join('')}</div><div class="budget-legend">${items.slice(0,4).map((x,i)=>`<div class="legend-row"><span class="legend-swatch" style="background:${['#86b89a','#b2d2ba','#d5e7cf','#efc7ad'][i%4]}"></span><div class="legend-copy"><strong>${escapeHtml(x.category)}</strong>${shortMoney(forecastFor(x))}</div></div>`).join('')}</div></article>
    </section>
    <section class="grid grid-2" style="margin-top:17px">
      <article class="panel"><div class="section-head"><div><h2>Ideas with your event in mind</h2><p>${escapeHtml(state.plan.theme||'A few ways to make it personal.')}</p></div><span class="tiny-icon">✦</span></div><div class="ideas-list">${(state.plan.ideas||[]).slice(0,4).map((idea,i)=>`<div class="idea-row"><span class="idea-number">${String(i+1).padStart(2,'0')}</span><p>${escapeHtml(idea)}</p></div>`).join('')}</div></article>
      <article class="panel"><div class="section-head"><div><h2>Vendor readiness</h2><p>Names and availability are not verified by Gatherly.</p></div><button class="link-button" data-goto="vendors">Open tracker →</button></div><div class="task-list">${state.vendors.slice(0,4).map(v=>`<div class="task-row"><span class="tiny-icon">◇</span><div><div class="task-title">${escapeHtml(v.name)}</div><div class="task-meta"><span>${escapeHtml(v.category)}</span></div></div><span class="pill ${statusPill(v.status)}">${escapeHtml(v.status)}</span></div>`).join('')||'<div class="empty-state"><h3>No vendor leads yet</h3><p>Add names manually or use the generated category checklist as your research guide.</p></div>'}</div><div style="margin-top:14px"><button class="button button-quiet" data-open-vendor>+ Add vendor lead</button></div></article>
    </section>`;
}
function statusPill(status) { if(status==='Confirmed'||status==='Attending'||status==='Quote received')return 'pill-green';if(status==='Shortlisted'||status==='Pending')return 'pill-blue';if(status==='Not proceeding'||status==='Declined')return 'pill-gray';if(status==='Contacted')return 'pill-yellow';return 'pill-peach'; }
function renderPlan() {
  const done=state.completedTasks.length;
  const sorted=state.plan.tasks.slice().sort((a,b)=>b.days_before-a.days_before);
  const groups=[{label:'EARLY PLANNING',match:t=>t.days_before>=30},{label:'DETAILS & CONFIRMATIONS',match:t=>t.days_before>=8&&t.days_before<30},{label:'FINAL WEEK',match:t=>t.days_before>=1&&t.days_before<8},{label:'EVENT DAY',match:t=>t.days_before===0}];
  const filtered=sorted.filter(t=>taskFilter==='all'||(taskFilter==='open'&&!state.completedTasks.includes(t.id))||(taskFilter==='done'&&state.completedTasks.includes(t.id)));
  return `<div class="view-intro"><div><h2>Your event, one step at a time.</h2><p>${done} of ${state.plan.tasks.length} tasks complete · dates are recalculated from your event date.</p></div><div class="filters"><select class="filter-select" id="task-filter"><option value="all" ${taskFilter==='all'?'selected':''}>All tasks</option><option value="open" ${taskFilter==='open'?'selected':''}>Open tasks</option><option value="done" ${taskFilter==='done'?'selected':''}>Completed</option></select><button class="button button-quiet" id="print-run-sheet">▤ Print run sheet</button></div></div>
    <div class="section-note"><strong>Planning note:</strong> Dates are suggestions calculated from the event date. Confirm deadlines and dependencies with your vendors. If the date changes, use <a href="#change" data-goto="change" style="color:#477a5c;font-weight:800">Change impact</a> to review the downstream effects.</div>
    <div class="panel"><div class="timeline">${groups.map(group=>{const tasks=filtered.filter(group.match);return tasks.length?`<section class="timeline-group"><div class="timeline-label">${group.label}</div>${tasks.map(t=>{const done=state.completedTasks.includes(t.id);return `<div class="timeline-card"><span class="timeline-marker">${done?'✓':(t.priority==='high'?'!':'·')}</span><div><div class="timeline-task-title ${done?'completed':''}">${escapeHtml(t.title)}</div><div class="timeline-task-detail">${escapeHtml(t.detail)}</div><div class="timeline-task-bottom"><span class="pill ${done?'pill-green':t.priority==='high'?'pill-peach':'pill-gray'}">${done?'Complete':`${escapeHtml(t.priority)} priority`}</span><span class="date-text">${escapeHtml(dueLabel(t))} · ${dateLabel(taskDate(t),{day:'numeric',month:'short',year:'numeric'})}</span><span class="date-text">${escapeHtml(t.category||'Planning')}</span></div></div><div class="task-actions"><span class="task-complete-label ${done?'done':''}">${done?'Done':'Mark done'}</span><input type="checkbox" class="task-check task-toggle" data-task="${escapeHtml(t.id)}" ${done?'checked':''} aria-label="Toggle task"></div></div>`}).join('')}</section>`:''}).join('')||'<div class="empty-state"><div class="empty-icon">✓</div><h3>No tasks in this filter</h3><p>Choose a different filter or generate a plan.</p></div>'}</div></div>
    <div class="grid grid-2" style="margin-top:16px"><article class="panel"><div class="section-head"><div><h2>Vendor checklist</h2><p>Categories suggested for this event type.</p></div></div><div class="ideas-list">${(state.plan.vendor_categories||[]).map((c,i)=>`<div class="idea-row"><span class="idea-number">${String(i+1).padStart(2,'0')}</span><p>${escapeHtml(c)}</p></div>`).join('')}</div><button class="button button-quiet" style="margin-top:15px" data-open-vendor>+ Add vendor to tracker</button></article><article class="panel"><div class="section-head"><div><h2>Assumptions to verify</h2><p>Keep the plan grounded in confirmed details.</p></div></div><div class="ideas-list">${(state.plan.risks||[]).map((r,i)=>`<div class="idea-row"><span class="idea-number" style="background:#fff1e8;color:#b77556">!</span><p>${escapeHtml(r)}</p></div>`).join('')}</div></article></div>`;
}
function renderBudget() {
  const t=budgetTotals(), remaining=t.headroom;
  return `<div class="view-intro"><div><h2>A budget you can explain.</h2><p>Each cost line has one forecast basis: committed, otherwise quoted, otherwise estimated.</p></div><div class="filters"><button class="button button-quiet" id="export-budget">⇩ Export CSV</button><button class="button button-primary" id="add-budget-item">+ Add cost line</button></div></div>
  <div class="budget-summary">${statCard('Budget cap',money(state.event.budget),`Event currency: ${escapeHtml(state.event.currency)}`,'₹','green')}${statCard('Current forecast',money(t.forecast),t.committed>0?`${money(t.committed)} committed on lines`:'Uses quotes where supplied, otherwise estimates','◫','blue')}${statCard(remaining<0?'Over budget':'Unallocated headroom',money(Math.abs(remaining)),remaining<0?'Forecast exceeds budget cap':'Cap less current forecast',remaining<0?'!':'✓',remaining<0?'peach':'yellow')}</div>
  <div class="section-note"><strong>Important:</strong> Starter allocations are illustrative planning splits, not local-market price research. Replace them with vendor quotes. Enter a quote or committed amount only when you have a source; the forecast will use one basis per line to avoid double-counting.</div>
  <article class="panel"><div class="section-head"><div><h2>Budget ledger</h2><p>Editable, separate values preserve estimate vs. quote vs. commitment.</p></div><span class="pill ${remaining<0?'pill-peach':'pill-green'}">${remaining<0?'Needs attention':'Within cap'}</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Cost category</th><th class="right">Estimate</th><th class="right">Quote</th><th class="right">Committed</th><th class="right">Paid</th><th class="right">Forecast</th><th></th></tr></thead><tbody>${state.budgetItems.map(item=>`<tr><td><strong>${escapeHtml(item.category)}</strong><div class="table-subtext">${item.estimate_mode==='allocation'?'Planning allocation':'Organizer estimate'}</div></td><td class="right"><input class="table-input budget-input" data-id="${escapeHtml(item.id)}" data-field="estimate" type="number" min="0" step="100" value="${Number(item.estimate)||0}" aria-label="Estimate for ${escapeHtml(item.category)}"></td><td class="right"><input class="table-input budget-input" data-id="${escapeHtml(item.id)}" data-field="quoted" type="number" min="0" step="100" value="${item.quoted===null||item.quoted===''?'':Number(item.quoted)}" placeholder="—" aria-label="Quote for ${escapeHtml(item.category)}"></td><td class="right"><input class="table-input budget-input" data-id="${escapeHtml(item.id)}" data-field="committed" type="number" min="0" step="100" value="${item.committed===null||item.committed===''?'':Number(item.committed)}" placeholder="—" aria-label="Committed amount for ${escapeHtml(item.category)}"></td><td class="right"><input class="table-input budget-input" data-id="${escapeHtml(item.id)}" data-field="paid" type="number" min="0" step="100" value="${Number(item.paid)||0}" aria-label="Paid amount for ${escapeHtml(item.category)}"></td><td class="right currency-cell"><strong>${money(forecastFor(item))}</strong><div class="table-subtext">${item.committed!==null&&item.committed!==''?'Committed':item.quoted!==null&&item.quoted!==''?'Quoted':'Estimated'}</div></td><td><button class="text-action remove-budget" data-id="${escapeHtml(item.id)}" title="Remove cost line">Remove</button></td></tr>`).join('')}</tbody><tfoot><tr><td><strong>Total</strong></td><td class="right"><strong>${money(t.estimate)}</strong></td><td class="right"><strong>${money(t.quoted)}</strong></td><td class="right"><strong>${money(t.committed)}</strong></td><td class="right"><strong>${money(t.paid)}</strong></td><td class="right"><strong>${money(t.forecast)}</strong></td><td></td></tr></tfoot></table></div><p class="small-print" style="margin:14px 0 0">Currency conversion is not performed. Keep all entries in the event currency. Use your source quote and validity date in the vendor notes, then update the linked cost line here.</p></article>
  <div class="grid grid-2" style="margin-top:16px"><article class="panel"><div class="section-head"><div><h2>Forecast basis</h2><p>Why this number is used.</p></div></div><div class="ideas-list"><div class="idea-row"><span class="idea-number">1</span><p><strong>Committed amount</strong> is used when you have approved a spend.</p></div><div class="idea-row"><span class="idea-number">2</span><p><strong>Quoted amount</strong> is used when a vendor quote is available but not yet committed.</p></div><div class="idea-row"><span class="idea-number">3</span><p><strong>Estimate</strong> is used when neither quote nor commitment exists.</p></div></div></article><article class="panel"><div class="section-head"><div><h2>Budget guardrails</h2><p>Simple checks before you approve a plan.</p></div></div><div class="ideas-list"><div class="idea-row"><span class="impact-bullet">${remaining<0?'!':'✓'}</span><p>${remaining<0?`The current forecast is ${money(Math.abs(remaining))} above your cap. Reduce scope or review quotes.`:`Current forecast leaves ${money(remaining)} of headroom against your budget cap.`}</p></div><div class="idea-row"><span class="impact-bullet">✓</span><p>${money(t.paid)} has been marked as paid. Do not confuse paid amounts with additional costs; they are progress against existing line items.</p></div></div></article></div>`;
}
function renderVendors() {
  return `<div class="view-intro"><div><h2>A source of truth for vendor conversations.</h2><p>Track the lead, the evidence and the next decision. No vendor facts are fabricated.</p></div><button class="button button-primary" data-open-vendor>+ Add vendor lead</button></div>
  <div class="grid grid-4" style="margin-bottom:16px">${statCard('Vendor leads',String(state.vendors.length),'Manually tracked businesses / categories','◇','green')}${statCard('Quotes received',String(state.vendors.filter(v=>v.status==='Quote received').length),'Quote status only, not independently verified','₹','blue')}${statCard('Shortlisted',String(state.vendors.filter(v=>v.status==='Shortlisted').length),'Organizer-selected options','✓','yellow')}${statCard('Confirmed',String(state.vendors.filter(v=>v.status==='Confirmed').length),'Check written scope & cancellation terms','!', 'peach')}</div>
  <div class="section-note"><strong>Vendor truth rule:</strong> a directory listing is a discovery lead, not a verified quote or a promise of availability. Record quote date, inclusions, taxes, deposit and cancellation terms. Confirm critical details directly with the vendor.</div>
  ${state.vendors.length?`<div class="vendor-grid">${state.vendors.map(v=>`<article class="vendor-card"><div class="vendor-card-top"><span class="vendor-icon">${escapeHtml((v.category||'V').slice(0,1).toUpperCase())}</span><div class="vendor-info"><strong>${escapeHtml(v.name)}</strong><small>${escapeHtml(v.category)}</small></div><button class="text-action remove-vendor" data-id="${escapeHtml(v.id)}" aria-label="Remove ${escapeHtml(v.name)}">×</button></div><div class="vendor-amount">${v.quote!==null&&v.quote!==''?money(v.quote):'Not quoted'} <small>${v.quote!==null&&v.quote!==''?'recorded quote':'price not available'}</small></div>${v.notes?`<p class="vendor-notes">${escapeHtml(v.notes)}</p>`:''}<div class="vendor-bottom"><select class="select-status vendor-status" data-id="${escapeHtml(v.id)}" aria-label="Status for ${escapeHtml(v.name)}">${['To research','Contacted','Quote received','Shortlisted','Confirmed','Not proceeding'].map(s=>`<option ${v.status===s?'selected':''}>${s}</option>`).join('')}</select><button class="text-action edit-vendor" data-id="${escapeHtml(v.id)}">View details ↗</button></div>${v.contact?`<div class="table-subtext" style="margin-top:9px">Contact: ${escapeHtml(v.contact)}</div>`:''}</article>`).join('')}</div>`:`<div class="panel empty-state"><div class="empty-icon">◇</div><h3>Your vendor tracker is ready</h3><p>Start with a category checklist, then add real vendor names and confirmed details.</p><button class="button button-primary" data-open-vendor>+ Add first vendor</button></div>`}
  <article class="panel" style="margin-top:16px"><div class="section-head"><div><h2>Suggested categories for this event</h2><p>Use this as a research checklist, not a list of endorsements.</p></div></div><div class="budget-legend">${(state.plan.vendor_categories||[]).map((c,i)=>`<div class="legend-row"><span class="legend-swatch" style="background:${['#86b89a','#b2d2ba','#efc7ad','#d7dbe5'][i%4]}"></span><div class="legend-copy"><strong>${escapeHtml(c)}</strong>Checklist item</div></div>`).join('')}</div></article>`;
}
function renderGuests() {
  const guests=state.guests.filter(g=>!guestSearch||`${g.name} ${g.note||''}`.toLowerCase().includes(guestSearch.toLowerCase()));
  const attending=state.guests.reduce((a,g)=>a+(g.rsvp==='Attending'?Number(g.party_size||1):0),0);
  const pending=state.guests.filter(g=>g.rsvp==='Invited'||g.rsvp==='Pending').length;
  const declined=state.guests.filter(g=>g.rsvp==='Declined').length;
  return `<div class="view-intro"><div><h2>Know who's joining you.</h2><p>Private-by-default guest tracking for the planning demo. No invites are sent from this screen.</p></div><button class="button button-primary" data-open-guest>+ Add guest</button></div>
  <div class="grid grid-3" style="margin-bottom:16px">${statCard('Guest target',Number(state.event.guests).toLocaleString('en-IN'),'Planned headcount','♙','green')}${statCard('Attending',String(attending),`${state.guests.filter(g=>g.rsvp==='Attending').length} records · includes party size`,'✓','blue')}${statCard('Waiting for response',String(pending),`${declined} declined`,'…','yellow')}</div>
  <div class="section-note"><strong>Privacy:</strong> guest names and notes are saved in this browser's local storage in demo mode. Avoid storing sensitive dietary, health or accessibility details here. This demo does not send invitations or share the guest roster.</div>
  <article class="panel"><div class="section-head"><div><h2>Guest roster</h2><p>${state.guests.length} records · target ${Number(state.event.guests).toLocaleString('en-IN')}</p></div><div class="guest-headline"><input class="search-input" id="guest-search" value="${escapeHtml(guestSearch)}" placeholder="Search guest names…" aria-label="Search guest names"><button class="button button-quiet" id="export-guests">⇩ Export CSV</button></div></div>
  ${guests.length?`<div class="table-wrap"><table class="data-table" style="min-width:560px"><thead><tr><th>Guest</th><th>Party size</th><th>RSVP status</th><th>Note</th><th></th></tr></thead><tbody>${guests.map(g=>`<tr><td><div class="guest-name-cell"><span class="guest-avatar">${escapeHtml(initials(g.name))}</span><div><strong>${escapeHtml(g.name)}</strong><div class="table-subtext">Added ${dateLabel(g.created_at?.slice(0,10)||todayISO())}</div></div></div></td><td>${Number(g.party_size||1)}</td><td><select class="rsvp-select guest-rsvp" data-id="${escapeHtml(g.id)}" aria-label="RSVP status for ${escapeHtml(g.name)}">${['Invited','Pending','Attending','Declined'].map(s=>`<option ${g.rsvp===s?'selected':''}>${s}</option>`).join('')}</select></td><td>${escapeHtml(g.note||'—')}</td><td><button class="text-action remove-guest" data-id="${escapeHtml(g.id)}">Remove</button></td></tr>`).join('')}</tbody></table></div>`:`<div class="empty-state"><div class="empty-icon">♙</div><h3>${guestSearch?'No matching guests':'Your guest list starts here'}</h3><p>${guestSearch?'Try a different search.':'Add guest names as you confirm your invite list, then update their RSVP status here.'}</p>${!guestSearch?'<button class="button button-primary" data-open-guest>+ Add first guest</button>':''}</div>`}</article>`;
}
function renderChange() {
  const e=state.event;
  return `<section class="change-hero"><div><div class="eyebrow"><span class="eyebrow-dot" style="background:#9dc8a9"></span> THE CHANGE-IMPACT ENGINE</div><h2>Change the inputs. See what moves.</h2><p>Preview likely cost and timeline impacts before updating your event. The forecast is a planning sensitivity—not a vendor quote or guaranteed outcome.</p></div><span class="pill" style="background:rgba(255,255,255,.12);color:#d6eadd;position:relative;z-index:1">Review before apply</span></section>
  <article class="panel change-form-panel"><div class="section-head"><div><h2>What changed?</h2><p>Compare a proposed scenario against your current event.</p></div><span class="pill pill-blue">Current: ${escapeHtml(e.title)}</span></div>
    <form id="change-form"><div class="change-grid"><label class="field"><span>New guest target</span><input type="number" id="change-guests" min="1" max="20000" required value="${Number(e.guests)}"></label><label class="field"><span>New event date</span><input type="date" id="change-date" required value="${escapeHtml(e.event_date)}"></label><label class="field"><span>New budget cap (${escapeHtml(e.currency)})</span><input type="number" id="change-budget" min="0" step="500" required value="${Number(e.budget)}"></label></div><div style="display:flex;justify-content:flex-end;margin-top:16px"><button class="button button-primary" id="preview-change" type="submit">Preview impact <span>→</span></button></div></form>
    ${changePreview?renderImpact(changePreview):'<div class="empty-state" style="padding-bottom:4px"><div class="empty-icon">↻</div><h3>No changes applied yet</h3><p>Try increasing the guest count, moving the date, or tightening the cap. We will show the proposed impacts before anything changes.</p></div>'}
  </article>
  <div class="grid grid-2" style="margin-top:16px"><article class="panel"><div class="section-head"><div><h2>What Gatherly will not do</h2><p>Trust is built by making the boundary clear.</p></div></div><div class="ideas-list"><div class="idea-row"><span class="impact-bullet">✓</span><p>It can flag food and activity lines that may vary with headcount.</p></div><div class="idea-row"><span class="impact-bullet">✓</span><p>It can recalculate task deadlines from a new event date.</p></div><div class="idea-row"><span class="impact-bullet">×</span><p>It will not silently rewrite approved plans, contact guests, book vendors or spend money.</p></div></div></article><article class="panel"><div class="section-head"><div><h2>Important assumptions</h2><p>Keep the organizer in control.</p></div></div><div class="ideas-list"><div class="idea-row"><span class="idea-number">1</span><p>Guest-sensitive cost lines are approximated from the current estimate and current headcount only.</p></div><div class="idea-row"><span class="idea-number">2</span><p>Venue capacity, taxes, vendor lead times and availability must be confirmed directly.</p></div><div class="idea-row"><span class="idea-number">3</span><p>Applying a scenario updates the event brief. Quotes and committed amounts remain untouched.</p></div></div></article></div>`;
}
function renderImpact(p) {
  const e=state.event;
  return `<div class="impact-results"><div class="section-head"><div><h2>Impact preview</h2><p>Nothing has changed yet. Review these likely downstream effects.</p></div><span class="pill pill-yellow">Draft scenario</span></div><div class="impact-cards"><div class="impact-metric"><small>Projected forecast</small><strong>${money(p.projectedForecast)}</strong><p>${p.projectedDelta===0?'No forecast change':`${p.projectedDelta>0?'+':''}${money(p.projectedDelta)} vs. current`}</p></div><div class="impact-metric"><small>Budget headroom</small><strong style="color:${p.headroom<0?'#b56545':'#467656'}">${money(p.headroom)}</strong><p>${p.headroom<0?'Forecast may exceed the new cap':'Based on this planning sensitivity'}</p></div><div class="impact-metric"><small>Task date shift</small><strong>${p.dateShift>0?'+':''}${p.dateShift} days</strong><p>${p.dateShift===0?'No schedule shift':`${state.plan.tasks.length} task dates recalculate`}</p></div></div><div class="section-head" style="margin-top:18px"><div><h2>Likely follow-ups</h2><p>Confirm these with responsible people before sending or booking.</p></div></div><div class="impact-list">${p.impacts.map((x,i)=>`<div class="impact-row"><span class="impact-bullet">${i+1}</span><span>${escapeHtml(x)}</span></div>`).join('')}</div><div class="section-note" style="margin-top:14px;margin-bottom:0">${escapeHtml(p.explanation)}</div><div class="impact-actions"><button class="button button-quiet" id="discard-change">Discard preview</button><button class="button button-primary" id="apply-change">Apply reviewed event changes <span>→</span></button></div></div>`;
}
function calculateImpact(next) {
  const oldGuests=Math.max(1,Number(state.event.guests)||1), newGuests=Math.max(1,Number(next.guests)||1);
  const t=budgetTotals();
  const sensitive=state.budgetItems.filter(x=>/food|cater|refresh|activity|transport|guest|meal/i.test(x.category));
  const currentGuestSensitive=sensitive.reduce((sum,x)=>sum+forecastFor(x),0);
  const delta=currentGuestSensitive/oldGuests*(newGuests-oldGuests);
  const projectedForecast=Math.max(0,t.forecast+delta);
  const dateShift=dayDiff(state.event.event_date,next.date);
  const impacts=[];
  if(newGuests!==oldGuests) {
    const diff=newGuests-oldGuests;
    impacts.push(`Guest target changes by ${diff>0?'+':''}${diff.toLocaleString('en-IN')} (${oldGuests.toLocaleString('en-IN')} → ${newGuests.toLocaleString('en-IN')}). Review catering quantities, seating, check-in, supplies and venue capacity.`);
    if(Math.abs(diff)/oldGuests>0.15) impacts.push('Headcount shift exceeds 15% of the current target: ask vendors for updated written quotes and capacity confirmation before relying on existing terms.');
    if(sensitive.length) impacts.push(`Guest-sensitive forecast lines (${sensitive.map(x=>x.category).join(', ')}) have a modeled change of ${delta>=0?'+':''}${money(delta)} using the current line forecasts per guest. This is a sensitivity estimate, not a market-price claim.`);
  }
  if(dateShift!==0) {
    impacts.push(`Event date moves ${dateShift>0?'later':'earlier'} by ${Math.abs(dateShift)} day(s). All ${state.plan.tasks.length} task deadlines recalculate from the new date; review any tasks that become overdue or too close to execution.`);
    impacts.push('Reconfirm venue hold, vendor availability, travel arrangements, invitation details and any contractual date-change terms. Existing confirmations are not changed automatically.');
  }
  if(Number(next.budget)!==Number(state.event.budget)) {
    impacts.push(`Budget cap changes from ${money(state.event.budget)} to ${money(next.budget)} (${Number(next.budget)-Number(state.event.budget)>=0?'+':''}${money(Number(next.budget)-Number(state.event.budget))}). Review scope and keep a contingency; current quotes and commitments remain unchanged.`);
  }
  if(!impacts.length) impacts.push('No differences detected. Change at least one input to see the impact preview.');
  if(Number(next.budget)<projectedForecast) impacts.push(`The modeled forecast of ${money(projectedForecast)} is above the new cap by ${money(projectedForecast-Number(next.budget))}. Identify a scope reduction before confirming additional spend.`);
  return {next,projectedForecast,projectedDelta:projectedForecast-t.forecast,headroom:Number(next.budget)-projectedForecast,dateShift,impacts,explanation:'Cost sensitivity uses your current ledger as the starting point. A quote, vendor capacity or actual price can behave differently; confirm material changes with the vendor. Applying this scenario updates only the event brief and relevant planning estimates, not vendor bookings or external messages.'};
}

function openEventDialog() {
  const e=state.event;
  $('#event-title').value=e.title; $('#event-type').value=e.event_type; $('#event-date').value=e.event_date; $('#event-city').value=e.city; $('#event-guests').value=e.guests; $('#event-budget').value=e.budget; $('#event-currency').value=e.currency; $('#event-preferences').value=e.preferences||'';
  $('#event-dialog').showModal();
}
function openVendorDialog(vendor=null) {
  $('#vendor-form').dataset.editId=vendor?.id||'';
  $('#vendor-name').value=vendor?.name||''; $('#vendor-category').value=vendor?.category||''; $('#vendor-status').value=vendor?.status||'To research'; $('#vendor-quote').value=vendor?.quote??''; $('#vendor-contact').value=vendor?.contact||''; $('#vendor-notes').value=vendor?.notes||'';
  $('#vendor-dialog').showModal();
}
function openGuestDialog() {
  $('#guest-name').value='';$('#guest-rsvp').value='Invited';$('#guest-party').value='1';$('#guest-note').value='';$('#guest-dialog').showModal();
}
function taskToggle(id,checked) {
  if(checked && !state.completedTasks.includes(id)) state.completedTasks.push(id);
  if(!checked) state.completedTasks=state.completedTasks.filter(x=>x!==id);
  logActivity(checked?'Task completed':'Task reopened',state.plan.tasks.find(t=>t.id===id)?.title||'Planning task'); saveState(); render();
}
function downloadFile(filename,content,mime='text/plain;charset=utf-8') {
  const blob=new Blob([content],{type:mime});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200);
}
function csvValue(v) { const s=String(v??''); return `"${s.replace(/"/g,'""')}"`; }
function exportBudget() {
  const rows=[['Category','Estimate','Quote','Committed','Paid','Forecast basis','Forecast amount','Currency'],...state.budgetItems.map(x=>[x.category,x.estimate,x.quoted??'',x.committed??'',x.paid,x.committed!==null&&x.committed!==''?'Committed':x.quoted!==null&&x.quoted!==''?'Quoted':'Estimated',forecastFor(x),state.event.currency])];
  downloadFile('gatherly-budget.csv',rows.map(r=>r.map(csvValue).join(',')).join('\r\n'),'text/csv;charset=utf-8');
}
function exportGuests() {
  const rows=[['Name','Party size','RSVP','Note'],...state.guests.map(g=>[g.name,g.party_size,g.rsvp,g.note||''])];
  downloadFile('gatherly-guests.csv',rows.map(r=>r.map(csvValue).join(',')).join('\r\n'),'text/csv;charset=utf-8');
}
function exportWorkspace() {
  const safeCopy={...state,exported_at:new Date().toISOString(),export_note:'Local demo backup. Contains guest/vendor notes; store and share carefully.'};
  downloadFile('gatherly-workspace-backup.json',JSON.stringify(safeCopy,null,2),'application/json;charset=utf-8');
  toast('Workspace backup exported. Keep it private if it contains guest details.');
}
function reassignTaskIds(plan) { return {...plan,tasks:(plan.tasks||[]).map(t=>({...t,id:uid('task')}))}; }
async function generatePlan() {
  const button=$('#generate-plan-btn'); const oldText=button.innerHTML;
  button.disabled=true;button.innerHTML='<span class="sparkle">✦</span> Building your plan…';
  try {
    const payload={event_type:state.event.event_type,title:state.event.title,event_date:state.event.event_date,city:state.event.city,guests:Number(state.event.guests),budget:Number(state.event.budget),currency:state.event.currency,preferences:state.event.preferences||'',priorities:state.event.priorities||['budget clarity','guest experience']};
    let result;
    try {
      const response=await fetch('/api/plan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      if(!response.ok) throw new Error('AI endpoint unavailable');
      result=await response.json();
    } catch(_) { result=localPlan(state.event); result.generation_mode='guided-demo'; }
    if(!result||!Array.isArray(result.tasks)||!Array.isArray(result.ideas)) throw new Error('The plan response was not usable.');
    state.plan=reassignTaskIds(result); state.completedTasks=[];
    logActivity('Planning draft generated',result.generation_mode==='gemini'?'Personalized draft from Gemini.':'Guided fallback template used.');
    saveState(); render(); toast(result.generation_mode==='gemini'?'Personalized AI plan generated. Review all suggestions.':'Guided plan generated. Add a Gemini key for live AI output.');
  } catch(e) { toast('Plan generation failed. Your existing plan was kept.'); }
  finally { const b=$('#generate-plan-btn');if(b){b.disabled=false;b.innerHTML=oldText;} }
}
function applyEventUpdate(next) {
  const oldGuests=Math.max(1,Number(state.event.guests)||1), newGuests=Math.max(1,Number(next.guests)||1);
  const ratio=newGuests/oldGuests;
  state.budgetItems.forEach(item=>{
    if(item.estimate_mode==='allocation' && /food|cater|refresh|activity|transport|guest|meal/i.test(item.category)) item.estimate=Math.round(Number(item.estimate||0)*ratio);
  });
  state.event={...state.event,...next};
  logActivity('Event details updated',`${state.event.title}: ${state.event.guests} guests, ${dateLabel(state.event.event_date,{day:'numeric',month:'short',year:'numeric'})}, cap ${money(state.event.budget)}`);
  changePreview=null;saveState();render();toast('Event details saved. Review timeline and budget after the change.');
}

// Event wiring
$('#edit-event-btn').addEventListener('click',openEventDialog);
$('#generate-plan-btn').addEventListener('click',generatePlan);
$('#mobile-menu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#export-data').addEventListener('click',exportWorkspace);
$('#dismiss-ai-banner').addEventListener('click',()=>{state.dismissBanner=true;saveState();updateBanner();});
document.querySelectorAll('.nav-item').forEach(btn=>btn.addEventListener('click',()=>setView(btn.dataset.view)));
document.body.addEventListener('click',e=>{
  const goto=e.target.closest('[data-goto]'); if(goto){e.preventDefault();setView(goto.dataset.goto);return;}
  const openVendor=e.target.closest('[data-open-vendor]');if(openVendor){openVendorDialog();return;}
  const openGuest=e.target.closest('[data-open-guest]');if(openGuest){openGuestDialog();return;}
  if(e.target.closest('#event-options')){openEventDialog();return;}
  if(e.target.closest('#add-budget-item')){const category=prompt('Cost category name:');if(category&&category.trim()){const estimate=amountNumber(prompt('Planning estimate (number only; optional):','0'))||0;state.budgetItems.push({id:uid('budget'),category:category.trim().slice(0,80),share:0,estimate,quoted:null,committed:null,paid:0,estimate_mode:'manual',icon:'◇'});logActivity('Budget line added',category.trim());saveState();render();}return;}
  if(e.target.closest('#export-budget')){exportBudget();return;}
  if(e.target.closest('#export-guests')){exportGuests();return;}
  if(e.target.closest('#print-run-sheet')){window.print();return;}
  if(e.target.closest('#discard-change')){changePreview=null;render();return;}
  if(e.target.closest('#apply-change')){if(!changePreview)return;const p=changePreview;applyEventUpdate({guests:Number(p.next.guests),event_date:p.next.date,budget:Number(p.next.budget)});return;}
  const removeBudget=e.target.closest('.remove-budget');if(removeBudget){const item=state.budgetItems.find(x=>x.id===removeBudget.dataset.id);if(item&&confirm(`Remove cost line "${item.category}"?`)){state.budgetItems=state.budgetItems.filter(x=>x.id!==item.id);logActivity('Budget line removed',item.category);saveState();render();}return;}
  const removeVendor=e.target.closest('.remove-vendor');if(removeVendor){const item=state.vendors.find(x=>x.id===removeVendor.dataset.id);if(item&&confirm(`Remove vendor lead "${item.name}"?`)){state.vendors=state.vendors.filter(x=>x.id!==item.id);saveState();render();toast('Vendor lead removed.');}return;}
  const editVendor=e.target.closest('.edit-vendor');if(editVendor){openVendorDialog(state.vendors.find(x=>x.id===editVendor.dataset.id));return;}
  const removeGuest=e.target.closest('.remove-guest');if(removeGuest){const item=state.guests.find(x=>x.id===removeGuest.dataset.id);if(item&&confirm(`Remove guest "${item.name}"?`)){state.guests=state.guests.filter(x=>x.id!==item.id);saveState();render();toast('Guest removed.');}return;}
});
appView.addEventListener('change',e=>{
  if(e.target.matches('.task-toggle')){taskToggle(e.target.dataset.task,e.target.checked);return;}
  if(e.target.matches('#task-filter')){taskFilter=e.target.value;render();return;}
  if(e.target.matches('.budget-input')){
    const item=state.budgetItems.find(x=>x.id===e.target.dataset.id);if(!item)return;
    const field=e.target.dataset.field; const val=amountNumber(e.target.value);
    if(field==='estimate'){item.estimate=val??0;item.estimate_mode='manual';}
    else item[field]=val;
    saveState();const cursor=e.target;const id=cursor.dataset.id;const fld=cursor.dataset.field;render();const newNode=document.querySelector(`.budget-input[data-id="${CSS.escape(id)}"][data-field="${CSS.escape(fld)}"]`);if(newNode){newNode.focus();newNode.setSelectionRange?.(newNode.value.length,newNode.value.length);}return;
  }
  if(e.target.matches('.vendor-status')){const v=state.vendors.find(x=>x.id===e.target.dataset.id);if(v){v.status=e.target.value;logActivity('Vendor status changed',`${v.name}: ${v.status}`);saveState();render();}return;}
  if(e.target.matches('.guest-rsvp')){const g=state.guests.find(x=>x.id===e.target.dataset.id);if(g){g.rsvp=e.target.value;logActivity('Guest RSVP updated',`${g.name}: ${g.rsvp}`);saveState();render();}return;}
});
appView.addEventListener('input',e=>{if(e.target.matches('#guest-search')){guestSearch=e.target.value;const pos=e.target.selectionStart;render();const node=$('#guest-search');if(node){node.focus();node.setSelectionRange(pos,pos);}}});

$('#event-form').addEventListener('submit',e=>{
  e.preventDefault();
  if(e.submitter?.value==='cancel'){$('#event-dialog').close();return;}
  const next={title:$('#event-title').value.trim(),event_type:$('#event-type').value,event_date:$('#event-date').value,city:$('#event-city').value.trim(),guests:Number($('#event-guests').value),budget:Number($('#event-budget').value),currency:$('#event-currency').value,preferences:$('#event-preferences').value.trim()};
  if(!next.title||!next.city||!next.event_date||next.guests<1||next.budget<0){toast('Please complete the required event details.');return;}
  $('#event-dialog').close();applyEventUpdate(next);
});
$('#vendor-form').addEventListener('submit',e=>{
  e.preventDefault();if(e.submitter?.value==='cancel'){$('#vendor-dialog').close();return;}
  const editId=$('#vendor-form').dataset.editId;
  const v={id:editId||uid('vendor'),name:$('#vendor-name').value.trim(),category:$('#vendor-category').value.trim(),status:$('#vendor-status').value,quote:amountNumber($('#vendor-quote').value),contact:$('#vendor-contact').value.trim(),notes:$('#vendor-notes').value.trim(),created_at:new Date().toISOString()};
  if(!v.name||!v.category){toast('Add the vendor name and category.');return;}
  if(editId){const idx=state.vendors.findIndex(x=>x.id===editId);if(idx>=0)state.vendors[idx]={...state.vendors[idx],...v};}else state.vendors.push(v);
  logActivity(editId?'Vendor lead updated':'Vendor lead added',`${v.name} · ${v.category}`);$('#vendor-dialog').close();saveState();render();toast(editId?'Vendor lead updated.':'Vendor lead added.');
});
$('#guest-form').addEventListener('submit',e=>{
  e.preventDefault();if(e.submitter?.value==='cancel'){$('#guest-dialog').close();return;}
  const g={id:uid('guest'),name:$('#guest-name').value.trim(),rsvp:$('#guest-rsvp').value,party_size:Number($('#guest-party').value)||1,note:$('#guest-note').value.trim(),created_at:new Date().toISOString()};
  if(!g.name||g.party_size<1){toast('Please enter a guest name and valid party size.');return;}
  state.guests.push(g);logActivity('Guest added',`${g.name} · ${g.rsvp}`);$('#guest-dialog').close();saveState();render();toast('Guest added. No invitation was sent.');
});
$('#change-form').addEventListener('submit',e=>{
  e.preventDefault();
  const next={guests:Number($('#change-guests').value),date:$('#change-date').value,budget:Number($('#change-budget').value)};
  if(!next.date||next.guests<1||next.budget<0){toast('Enter a valid date, guest target and budget cap.');return;}
  changePreview=calculateImpact(next);render();
});

async function checkHealth() {
  try {
    const r=await fetch('/api/health');if(!r.ok)return;const h=await r.json();
    if(h.ai_enabled && state.plan.generation_mode!=='gemini' && !state.dismissBanner) {
      const banner=$('#ai-status-banner');banner.classList.add('live');banner.querySelector('strong').textContent=`Live GenAI ready · ${h.model}`;banner.querySelector('small').textContent='When you click Generate, the event brief is sent to Google Gemini; guest lists and vendor notes are not included. The current plan remains editable.';
    }
  } catch(_) { /* Static preview mode: full manual workflow still works. */ }
}

// Initial page setup: the server workspace is authoritative; local storage is a recovery cache.
async function bootGatherly() {
  render();
  setSaveStatus('Connecting to workspace…');
  try {
    const response=await fetch('/api/workspace');
    if(!response.ok)throw new Error('Workspace API unavailable');
    const remote=await response.json();
    const localTime=Date.parse(cachedLocalState?.lastSaved||'')||0;
    const remoteTime=Date.parse(remote.updated_at||'')||0;
    if(remote.state && typeof remote.state==='object' && remoteTime>=localTime) {
      state=normalizeState(remote.state);
      localStorage.setItem(STORE_KEY,JSON.stringify(state));
      setSaveStatus('Synced from server');
      render();
    } else {
      // No server copy yet, or this device has a newer unsynced recovery copy.
      saveState();
    }
  } catch(_) {
    setSaveStatus('Saved on this device',true);
  }
  checkHealth();
}
bootGatherly();
